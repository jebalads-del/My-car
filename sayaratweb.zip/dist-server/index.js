// server/_core/index.ts
import "dotenv/config";
import { existsSync } from "node:fs";
import path from "node:path";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { z as z6 } from "zod";

// server/_core/oauth.ts
import { createHash, randomBytes } from "node:crypto";
import { and, eq as eq2, gt, isNull } from "drizzle-orm";
import { parse as parseCookieHeader2 } from "cookie";
import { z } from "zod";

// drizzle/schema.ts
import {
  boolean,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar
} from "drizzle-orm/mysql-core";
var users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  blocked: boolean("blocked").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
});
var localCredentials = mysqlTable("local_credentials", {
  userId: int("userId").primaryKey().references(() => users.id),
  passwordHash: text("passwordHash").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var otpCodes = mysqlTable("otp_codes", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  purpose: mysqlEnum("purpose", ["register", "reset"]).notNull(),
  codeHash: varchar("codeHash", { length: 128 }).notNull(),
  name: text("name"),
  passwordHash: text("passwordHash"),
  expiresAt: timestamp("expiresAt").notNull(),
  consumedAt: timestamp("consumedAt"),
  attempts: int("attempts").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var marketSettings = mysqlTable("market_settings", {
  id: int("id").primaryKey(),
  brands: json("brands").$type().notNull(),
  currencies: json("currencies").$type().notNull(),
  terms: text("terms").notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }).notNull(),
  contactPhone: varchar("contactPhone", { length: 32 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 64 }).notNull(),
  paypalEnabled: boolean("paypalEnabled").default(false).notNull(),
  paypalUrl: varchar("paypalUrl", { length: 512 }).notNull(),
  westernEnabled: boolean("westernEnabled").default(false).notNull(),
  westernInstructions: text("westernInstructions").notNull(),
  featuredPrice: decimal("featuredPrice", { precision: 14, scale: 2 }).notNull(),
  featuredDays: int("featuredDays").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var listings = mysqlTable(
  "listings",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id),
    brand: varchar("brand", { length: 80 }).notNull(),
    model: varchar("model", { length: 120 }).notNull(),
    year: int("year").notNull(),
    color: varchar("color", { length: 64 }).notNull(),
    price: decimal("price", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 8 }).notNull(),
    mileage: int("mileage").notNull(),
    location: varchar("location", { length: 120 }).notNull(),
    description: text("description").notNull(),
    transmission: varchar("transmission", { length: 64 }).notNull(),
    fuel: varchar("fuel", { length: 64 }).notNull(),
    condition: varchar("condition", { length: 64 }).notNull(),
    images: json("images").$type().notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected", "sold", "archived"]).default("pending").notNull(),
    featured: boolean("featured").default(false).notNull(),
    featuredUntil: timestamp("featuredUntil"),
    rejectionReason: text("rejectionReason"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
  },
  (table) => [
    index("listings_status_featured_created_idx").on(table.status, table.featured, table.createdAt),
    index("listings_user_created_idx").on(table.userId, table.createdAt)
  ]
);
var uploadedAssets = mysqlTable(
  "uploaded_assets",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    url: varchar("url", { length: 768 }).notNull(),
    mime: varchar("mime", { length: 32 }).notNull(),
    bytes: int("bytes").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("uploaded_assets_storage_key_uq").on(table.storageKey),
    uniqueIndex("uploaded_assets_url_uq").on(table.url),
    index("uploaded_assets_user_created_idx").on(table.userId, table.createdAt)
  ]
);
var featuredRequests = mysqlTable(
  "featured_requests",
  {
    id: int("id").autoincrement().primaryKey(),
    listingId: int("listingId").notNull().references(() => listings.id),
    userId: int("userId").notNull().references(() => users.id),
    method: mysqlEnum("method", ["paypal", "western"]).notNull(),
    reference: varchar("reference", { length: 256 }).notNull(),
    amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
    duration: int("duration").notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
    decidedAt: timestamp("decidedAt"),
    decidedByUserId: int("decidedByUserId").references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull()
  },
  (table) => [
    index("featured_requests_listing_status_idx").on(table.listingId, table.status),
    index("featured_requests_user_created_idx").on(table.userId, table.createdAt)
  ]
);
var contactMessages = mysqlTable(
  "contact_messages",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    message: text("message").notNull(),
    ipHash: varchar("ipHash", { length: 64 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull()
  },
  (table) => [index("contact_messages_ip_created_idx").on(table.ipHash, table.createdAt)]
);
var oauthNonces = mysqlTable(
  "oauth_nonces",
  {
    id: int("id").autoincrement().primaryKey(),
    nonceHash: varchar("nonceHash", { length: 64 }).notNull(),
    redirectUri: varchar("redirectUri", { length: 1024 }).notNull(),
    frontendOrigin: varchar("frontendOrigin", { length: 512 }),
    expiresAt: timestamp("expiresAt").notNull(),
    usedAt: timestamp("usedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("oauth_nonces_nonce_hash_uq").on(table.nonceHash),
    index("oauth_nonces_expiry_idx").on(table.expiresAt)
  ]
);

// shared/const.ts
var SESSION_COOKIE_SUFFIX = "216154127124529";
var LEGACY_COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/db.ts
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// server/_core/env.ts
var ENV = {
  appId: process.env.MANUS_PROJECT_ID ?? process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.MANUS_JWT_SECRET ?? process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.MANUS_OAUTH_API_URL ?? process.env.OAUTH_SERVER_URL ?? "",
  oAuthPortalUrl: process.env.MANUS_OAUTH_PORTAL_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? ""
};

// server/db.ts
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch {
      console.warn("[Database] Failed to connect");
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values = {
      openId: user.openId
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== void 0) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = /* @__PURE__ */ new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user");
    throw error;
  }
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return void 0;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}

// server/_core/cookies.ts
import { parse as parseCookieHeader } from "cookie";
function configuredPublicUsesHttps(req) {
  const forwardedHost = req.headers["x-forwarded-host"];
  const requestHosts = new Set(
    [
      req.hostname,
      ...(Array.isArray(forwardedHost) ? forwardedHost : [forwardedHost]).flatMap(
        (value) => value ? value.split(",") : []
      )
    ].filter(Boolean).map((host) => host.trim().toLowerCase().replace(/:\d+$/, ""))
  );
  const candidates = [
    process.env.EXPO_WEB_PREVIEW_URL,
    process.env.EXPO_PACKAGER_PROXY_URL,
    process.env.EXPO_PUBLIC_API_BASE_URL
  ];
  return candidates.some((candidate) => {
    try {
      const url = new URL(candidate);
      return url.protocol === "https:" && requestHosts.has(url.hostname.toLowerCase());
    } catch {
      return false;
    }
  });
}
function isSecureRequest(req) {
  if (configuredPublicUsesHttps(req)) return true;
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  const secure = isSecureRequest(req);
  return {
    httpOnly: true,
    path: "/",
    sameSite: secure ? "none" : "lax",
    secure
  };
}
function configuredApiHostname() {
  const packager = process.env.EXPO_PACKAGER_PROXY_URL;
  if (!packager) return null;
  try {
    const url = new URL(packager);
    const hostname = url.hostname.replace(/^8081-/, "3000-");
    return hostname === url.hostname ? null : hostname;
  } catch {
    return null;
  }
}
function legacyParentDomain(hostname) {
  const normalized = hostname.toLowerCase();
  if (normalized !== configuredApiHostname()?.toLowerCase()) return null;
  if (!/^3000-[a-z0-9-]+(?:\.[a-z0-9-]+){2,}$/.test(normalized)) return null;
  return `.${normalized.split(".").slice(-2).join(".")}`;
}
function getSessionCookieName(req) {
  return isSecureRequest(req) ? `__Host-manus_session_${SESSION_COOKIE_SUFFIX}` : `manus_local_session_${SESSION_COOKIE_SUFFIX}`;
}
function getLegacySessionCookieOptions(req) {
  const secure = isSecureRequest(req);
  return {
    domain: legacyParentDomain(req.hostname) ?? void 0,
    httpOnly: true,
    path: "/",
    sameSite: secure ? "none" : "lax",
    secure
  };
}
function clearLegacySessionCookie() {
  return (req, res, next) => {
    res.clearCookie(LEGACY_COOKIE_NAME, getLegacySessionCookieOptions(req));
    next();
  };
}
function currentSessionCookie(req) {
  if (!req.headers.cookie) return void 0;
  return parseCookieHeader(req.headers.cookie)[getSessionCookieName(req)];
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { SignJWT, jwtVerify } from "jose";
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Client initialized");
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  async getTokenByCode(code, redirectUri) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri
    };
    const { data } = await this.client.post(EXCHANGE_TOKEN_PATH, payload);
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(GET_USER_INFO_PATH, {
      accessToken: token.accessToken
    });
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(platforms.filter((p) => typeof p === "string"));
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, redirectUri) {
    return this.oauthService.getTokenByCode(code, redirectUri);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name, exp } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || typeof name !== "string" || typeof exp !== "number" || exp * 1e3 <= Date.now() || !ENV.appId || appId !== ENV.appId) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch {
      console.warn("[Auth] Session verification failed");
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const authHeader = req.headers.authorization || req.headers.Authorization;
    let token;
    if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
      token = authHeader.slice("Bearer ".length).trim();
    }
    const sessionCookie = token || currentSessionCookie(req);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    if (session.openId.startsWith(CRON_OPEN_ID_PREFIX)) {
      const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
      const taskUid = userInfo.taskUid ?? null;
      if (!taskUid) {
        throw ForbiddenError("Cron session missing task_uid");
      }
      return buildCronUser(userInfo);
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch {
        console.error("[Auth] Failed to sync user from OAuth");
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    if (user.blocked) {
      throw ForbiddenError("User account is blocked");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var CRON_OPEN_ID_PREFIX = "cron_";
function buildCronUser(userInfo) {
  const now = /* @__PURE__ */ new Date();
  return {
    id: -1,
    openId: userInfo.openId,
    name: userInfo.name || "Manus Scheduled Task",
    email: null,
    loginMethod: null,
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    taskUid: userInfo.taskUid ?? void 0,
    isCron: true
  };
}
var sdk = new SDKServer();

// server/_core/oauth.ts
var OAUTH_NONCE_COOKIE = "manus_oauth_nonce";
var OAUTH_NONCE_TTL_MS = 10 * 60 * 1e3;
var NATIVE_FRONTEND = "native";
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function hashNonce(nonce) {
  return createHash("sha256").update(nonce).digest("hex");
}
function encodeState(state) {
  return Buffer.from(JSON.stringify(state), "utf8").toString("base64url");
}
function parseState(value) {
  try {
    const parsed = JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
    if (!parsed || typeof parsed !== "object" || typeof parsed.redirectUri !== "string" || typeof parsed.nonce !== "string" || !/^[A-Za-z0-9_-]{32,128}$/.test(parsed.nonce) || parsed.redirectUri.length > 1024) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}
function urlOrigin(value) {
  try {
    const url = new URL(value);
    return (url.protocol === "https:" || url.protocol === "http:") && url.origin === value ? url.origin : null;
  } catch {
    return null;
  }
}
function configuredOrigin(value) {
  return value ? urlOrigin(value) : null;
}
function configuredApiOrigins(req) {
  const origins = /* @__PURE__ */ new Set();
  for (const value of [
    process.env.EXPO_PUBLIC_API_BASE_URL,
    process.env.MANUS_ADDON_RUNTIME_PUBLIC_ORIGIN
  ]) {
    const origin = configuredOrigin(value);
    if (origin) origins.add(origin);
  }
  const host = req.get("host");
  if (host) {
    const proto = req.headers["x-forwarded-proto"]?.toString().split(",")[0]?.trim() || req.protocol;
    if (proto === "https" || proto === "http") origins.add(`${proto}://${host}`);
  }
  return origins;
}
function configuredFrontendOrigins() {
  const origins = /* @__PURE__ */ new Set();
  for (const value of [process.env.EXPO_WEB_PREVIEW_URL, process.env.EXPO_PACKAGER_PROXY_URL]) {
    const origin = configuredOrigin(value);
    if (origin) origins.add(origin);
  }
  return origins;
}
function validatePrepareRequest(input, req) {
  if (input.frontendOrigin === NATIVE_FRONTEND) {
    try {
      const redirect2 = new URL(input.redirectUri);
      if (redirect2.protocol === "http:" || redirect2.protocol === "https:" || !/^[a-z][a-z0-9+.-]*:$/i.test(redirect2.protocol)) {
        throw new Error("not-native");
      }
      return "native";
    } catch {
      throw new Error("Invalid native redirect URI");
    }
  }
  const frontendOrigin = urlOrigin(input.frontendOrigin);
  let redirect;
  try {
    redirect = new URL(input.redirectUri);
  } catch {
    throw new Error("Invalid web redirect URI");
  }
  if (!frontendOrigin || !configuredFrontendOrigins().has(frontendOrigin) || redirect.protocol !== "https:" || redirect.pathname !== "/api/oauth/callback" || redirect.search || redirect.hash || !configuredApiOrigins(req).has(redirect.origin)) {
    throw new Error("Untrusted OAuth redirect");
  }
  return "web";
}
function oauthNonceCookie(req) {
  const secureOptions = getSessionCookieOptions(req);
  return {
    httpOnly: true,
    path: "/api/oauth",
    sameSite: secureOptions.sameSite,
    secure: secureOptions.secure
  };
}
function readNonceCookie(req) {
  if (!req.headers.cookie) return void 0;
  return parseCookieHeader2(req.headers.cookie)[OAUTH_NONCE_COOKIE];
}
async function syncUser(userInfo) {
  if (!userInfo.openId) {
    throw new Error("openId missing from user info");
  }
  const lastSignedIn = /* @__PURE__ */ new Date();
  await upsertUser({
    openId: userInfo.openId,
    name: userInfo.name || null,
    email: userInfo.email ?? null,
    loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
    lastSignedIn
  });
  const saved = await getUserByOpenId(userInfo.openId);
  return saved ?? {
    openId: userInfo.openId,
    name: userInfo.name,
    email: userInfo.email,
    phone: null,
    loginMethod: userInfo.loginMethod ?? null,
    role: "user",
    blocked: false,
    lastSignedIn
  };
}
function buildUserResponse(user) {
  return {
    id: user?.id ?? null,
    openId: user?.openId ?? null,
    name: user?.name ?? null,
    email: user?.email ?? null,
    phone: user?.phone ?? null,
    loginMethod: user?.loginMethod ?? null,
    role: user?.role ?? "user",
    blocked: Boolean(user?.blocked),
    lastSignedIn: (user?.lastSignedIn ?? /* @__PURE__ */ new Date()).toISOString()
  };
}
async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return db;
}
async function findNonce(state) {
  const db = await requireDb();
  return (await db.select().from(oauthNonces).where(
    and(
      eq2(oauthNonces.nonceHash, hashNonce(state.nonce)),
      eq2(oauthNonces.redirectUri, state.redirectUri),
      isNull(oauthNonces.usedAt),
      gt(oauthNonces.expiresAt, /* @__PURE__ */ new Date())
    )
  ).limit(1))[0];
}
async function consumeNonce(state) {
  const db = await requireDb();
  return db.transaction(async (tx) => {
    const nonce = (await tx.select().from(oauthNonces).where(
      and(
        eq2(oauthNonces.nonceHash, hashNonce(state.nonce)),
        eq2(oauthNonces.redirectUri, state.redirectUri),
        isNull(oauthNonces.usedAt),
        gt(oauthNonces.expiresAt, /* @__PURE__ */ new Date())
      )
    ).limit(1).for("update"))[0];
    if (!nonce) throw new Error("Invalid or already used OAuth state");
    await tx.update(oauthNonces).set({ usedAt: /* @__PURE__ */ new Date() }).where(eq2(oauthNonces.id, nonce.id));
    return nonce;
  });
}
async function finishOAuth(code, state) {
  const tokenResponse = await sdk.exchangeCodeForToken(code, state.redirectUri);
  const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
  const user = await syncUser(userInfo);
  if (user.blocked) throw new Error("Blocked account");
  const sessionToken = await sdk.createSessionToken(userInfo.openId, {
    name: userInfo.name || "",
    expiresInMs: ONE_YEAR_MS
  });
  return { sessionToken, user };
}
function registerOAuthRoutes(app) {
  app.post("/api/oauth/prepare", async (req, res) => {
    const parsed = zPrepare.safeParse(req.body);
    if (!parsed.success || !ENV.appId || !ENV.oAuthPortalUrl) {
      res.status(400).json({ error: "invalid_oauth_prepare_request" });
      return;
    }
    try {
      const flow = validatePrepareRequest(parsed.data, req);
      const nonce = randomBytes(32).toString("base64url");
      const state = encodeState({ redirectUri: parsed.data.redirectUri, nonce });
      const db = await requireDb();
      await db.insert(oauthNonces).values({
        nonceHash: hashNonce(nonce),
        redirectUri: parsed.data.redirectUri,
        frontendOrigin: flow === "web" ? parsed.data.frontendOrigin : null,
        expiresAt: new Date(Date.now() + OAUTH_NONCE_TTL_MS)
      });
      if (flow === "web") {
        res.cookie(OAUTH_NONCE_COOKIE, nonce, { ...oauthNonceCookie(req), maxAge: OAUTH_NONCE_TTL_MS });
      }
      const url = new URL("app-auth", ENV.oAuthPortalUrl.replace(/\/$/, "") + "/");
      url.searchParams.set("appId", ENV.appId);
      url.searchParams.set("redirectUri", parsed.data.redirectUri);
      url.searchParams.set("state", state);
      url.searchParams.set("responseType", "code");
      res.json({ url: url.toString(), state });
    } catch {
      res.status(400).json({ error: "invalid_oauth_prepare_request" });
    }
  });
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const encodedState = getQueryParam(req, "state");
    const state = encodedState ? parseState(encodedState) : null;
    if (!code || !state) {
      res.status(400).json({ error: "invalid_oauth_callback" });
      return;
    }
    try {
      const nonce = await findNonce(state);
      if (!nonce?.frontendOrigin || readNonceCookie(req) !== state.nonce) {
        res.status(400).json({ error: "invalid_oauth_state" });
        return;
      }
      const consumed = await consumeNonce(state);
      const { sessionToken } = await finishOAuth(code, state);
      if (!consumed.frontendOrigin) throw new Error("Missing web frontend origin");
      res.cookie(getSessionCookieName(req), sessionToken, {
        ...getSessionCookieOptions(req),
        maxAge: ONE_YEAR_MS
      });
      res.clearCookie(OAUTH_NONCE_COOKIE, oauthNonceCookie(req));
      res.redirect(302, consumed.frontendOrigin);
    } catch {
      console.error("[OAuth] Secure web callback failed");
      res.status(500).json({ error: "oauth_callback_failed" });
    }
  });
  app.get("/api/oauth/mobile", async (req, res) => {
    const code = getQueryParam(req, "code");
    const encodedState = getQueryParam(req, "state");
    const state = encodedState ? parseState(encodedState) : null;
    if (!code || !state) {
      res.status(400).json({ error: "invalid_oauth_callback" });
      return;
    }
    try {
      const nonce = await findNonce(state);
      if (!nonce || nonce.frontendOrigin !== null) {
        res.status(400).json({ error: "invalid_oauth_state" });
        return;
      }
      await consumeNonce(state);
      const { sessionToken, user } = await finishOAuth(code, state);
      res.json({ app_session_id: sessionToken, user: buildUserResponse(user) });
    } catch {
      console.error("[OAuth] Secure mobile exchange failed");
      res.status(500).json({ error: "oauth_callback_failed" });
    }
  });
  app.post("/api/auth/logout", (req, res) => {
    const cookieOptions2 = getSessionCookieOptions(req);
    res.clearCookie(getSessionCookieName(req), { ...cookieOptions2, maxAge: -1 });
    res.json({ success: true });
  });
  app.get("/api/auth/me", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ user: buildUserResponse(user) });
    } catch {
      res.status(401).json({ error: "Not authenticated", user: null });
    }
  });
  app.post("/api/auth/session", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (typeof authHeader !== "string" || !authHeader.startsWith("Bearer ")) {
        res.status(400).json({ error: "Bearer token required" });
        return;
      }
      const token = authHeader.slice("Bearer ".length).trim();
      res.cookie(getSessionCookieName(req), token, {
        ...getSessionCookieOptions(req),
        maxAge: ONE_YEAR_MS
      });
      res.json({ success: true, user: buildUserResponse(user) });
    } catch {
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
var zPrepare = z.object({
  redirectUri: z.string().trim().min(1).max(1024),
  frontendOrigin: z.string().trim().min(1).max(512)
}).strict();

// server/_core/storageProxy.ts
function registerStorageProxy(app) {
  app.get("/manus-storage/*", async (req, res) => {
    const key = req.params[0];
    if (!key) {
      res.status(400).send("Missing storage key");
      return;
    }
    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      res.status(500).send("Storage proxy not configured");
      return;
    }
    try {
      const forgeUrl = new URL(
        "v1/storage/presign/get",
        ENV.forgeApiUrl.replace(/\/+$/, "") + "/"
      );
      forgeUrl.searchParams.set("path", key);
      const forgeResp = await fetch(forgeUrl, {
        headers: { Authorization: `Bearer ${ENV.forgeApiKey}` }
      });
      if (!forgeResp.ok) {
        await forgeResp.body?.cancel().catch(() => void 0);
        console.error("[StorageProxy] forge request failed");
        res.status(502).send("Storage backend error");
        return;
      }
      const { url } = await forgeResp.json();
      if (!url) {
        res.status(502).send("Empty signed URL from backend");
        return;
      }
      res.set("Cache-Control", "no-store");
      res.redirect(307, url);
    } catch {
      console.error("[StorageProxy] failed");
      res.status(502).send("Storage proxy error");
    }
  });
}

// server/_core/systemRouter.ts
import { z as z2 } from "zod";

// server/_core/notification.ts
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL("webdevtoken.v1.WebDevService/SendNotification", normalizedBase).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      await response.body?.cancel().catch(() => void 0);
      console.warn("[Notification] Failed to notify owner");
      return false;
    }
    return true;
  } catch {
    console.warn("[Notification] Error calling notification service");
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  if (ctx.user.blocked) {
    throw new TRPCError2({ code: "FORBIDDEN", message: "This account is blocked" });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.blocked || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z2.object({
      timestamp: z2.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z2.object({
      title: z2.string().min(1, "title is required"),
      content: z2.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/supabase-client.ts
import { randomUUID } from "node:crypto";
var SupabaseRequestError = class extends Error {
  constructor(message, status, code) {
    super(message);
    this.status = status;
    this.code = code;
    this.name = "SupabaseRequestError";
  }
};
function isSupabaseConfigured() {
  return Boolean(process.env.SUPABASE_URL?.trim() && process.env.SUPABASE_ANON_KEY?.trim());
}
function getSupabaseConfig() {
  const url = process.env.SUPABASE_URL?.trim().replace(/\/$/, "");
  const anonKey = process.env.SUPABASE_ANON_KEY?.trim();
  if (!url || !anonKey) throw new SupabaseRequestError("Supabase \u063A\u064A\u0631 \u0645\u0647\u064A\u0623", 503, "SUPABASE_UNAVAILABLE");
  let privileged = anonKey.startsWith("sb_secret_");
  try {
    privileged ||= JSON.parse(Buffer.from(anonKey.split(".")[1] ?? "", "base64url").toString()).role === "service_role";
  } catch {
  }
  if (privileged) throw new SupabaseRequestError("\u0627\u0633\u062A\u062E\u062F\u0645 \u0645\u0641\u062A\u0627\u062D Supabase \u0627\u0644\u0639\u0627\u0645 \u0648\u0644\u064A\u0633 \u0645\u0641\u062A\u0627\u062D \u0627\u0644\u0625\u062F\u0627\u0631\u0629", 503, "SUPABASE_KEY_TYPE_INVALID");
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) throw new Error("invalid project URL");
  } catch {
    throw new SupabaseRequestError("\u0625\u0639\u062F\u0627\u062F Supabase \u063A\u064A\u0631 \u0635\u0627\u0644\u062D", 503, "SUPABASE_UNAVAILABLE");
  }
  return { url, anonKey };
}
function safeErrorMessage(payload) {
  if (payload && typeof payload === "object") {
    const record = payload;
    const message = record.msg ?? record.message ?? record.error_description ?? record.error;
    const code = typeof record.error_code === "string" ? record.error_code : typeof record.code === "string" ? record.code : void 0;
    if (typeof message === "string" && message.length <= 500) return { message, code };
  }
  return { message: "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u062E\u062F\u0645\u0629" };
}
async function supabaseFetch(path2, init = {}, accessToken) {
  const { url, anonKey } = getSupabaseConfig();
  const headers = new Headers(init.headers);
  headers.set("apikey", anonKey);
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  else if (anonKey.split(".").length === 3) headers.set("Authorization", `Bearer ${anonKey}`);
  else headers.delete("Authorization");
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  let response;
  try {
    response = await fetch(`${url}${path2.startsWith("/") ? path2 : `/${path2}`}`, { ...init, headers, signal: init.signal ?? AbortSignal.timeout(2e4) });
  } catch {
    throw new SupabaseRequestError("\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0640 Supabase", 503, "SUPABASE_UNAVAILABLE");
  }
  if (!response.ok) {
    const payload = await response.json().catch(() => null);
    const detail = safeErrorMessage(payload);
    throw new SupabaseRequestError(detail.message, response.status, detail.code);
  }
  return response;
}
async function supabaseJson(path2, init = {}, accessToken) {
  const response = await supabaseFetch(path2, init, accessToken);
  if (response.status === 204) return void 0;
  return await response.json();
}
async function supabaseAuthJson(path2, body, accessToken) {
  return supabaseJson(`/auth/v1/${path2.replace(/^\//, "")}`, {
    method: "POST",
    body: JSON.stringify(body)
  }, accessToken);
}
async function supabaseGetUser(accessToken) {
  const response = await supabaseFetch("/auth/v1/user", { method: "GET" }, accessToken);
  return await response.json();
}
function storagePublicUrl(key) {
  const { url } = getSupabaseConfig();
  return `${url}/storage/v1/object/public/car-images/${key.split("/").map(encodeURIComponent).join("/")}`;
}
async function uploadCarImage(authUserId, bytes, contentType, accessToken) {
  const key = `cars/${authUserId}/${randomUUID()}.jpg`;
  await supabaseFetch(`/storage/v1/object/car-images/${key.split("/").map(encodeURIComponent).join("/")}`, {
    method: "POST",
    headers: { "Content-Type": contentType, "x-upsert": "false" },
    body: new Uint8Array(bytes)
  }, accessToken);
  return { key, url: storagePublicUrl(key) };
}
function isOwnedPublicCarImage(url, authUserId) {
  const prefix = storagePublicUrl(`cars/${authUserId}/`);
  return url.startsWith(prefix) && !url.slice(prefix.length).includes("/");
}

// server/supabase-auth.ts
import { randomBytes as randomBytes2 } from "node:crypto";
import { z as z3 } from "zod";
import { TRPCError as TRPCError3 } from "@trpc/server";

// server/supabase-cookies.ts
import { parse as parseCookie } from "cookie";
function supabaseCookieOptions(req) {
  const options = getSessionCookieOptions(req);
  return { ...options, ...options.secure ? { partitioned: true } : {} };
}
function supabaseCookieNames(req) {
  const prefix = getSessionCookieOptions(req).secure ? "__Host-sayarty" : "sayarty_local";
  return {
    access: `${prefix}_session_${SESSION_COOKIE_SUFFIX}`,
    refresh: `${prefix}_refresh_${SESSION_COOKIE_SUFFIX}`,
    probe: `${prefix}_transport_${SESSION_COOKIE_SUFFIX}`
  };
}
function readSupabaseCookie(req, kind) {
  const cookies = parseCookie(req.headers.cookie || "");
  return cookies[`__Host-sayarty_${kind}_${SESSION_COOKIE_SUFFIX}`] || cookies[`sayarty_local_${kind}_${SESSION_COOKIE_SUFFIX}`];
}

// server/supabase-auth.ts
var emailSchema = z3.string().trim().email().max(320);
var passwordSchema = z3.string().min(8).max(256);
var nameSchema = z3.string().trim().min(2).max(100);
var codeSchema = z3.string().trim().min(4).max(512);
function authError(error) {
  if (error instanceof SupabaseRequestError) {
    if (error.code === "PROFILE_UNAVAILABLE") return { status: 403, code: "PROFILE_UNAVAILABLE", error: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644 \u0635\u062D\u064A\u062D\u0629\u060C \u0644\u0643\u0646 \u0645\u0644\u0641 \u062D\u0633\u0627\u0628\u0643 \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D. \u064A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u0629 \u0631\u0628\u0637 \u0627\u0644\u062D\u0633\u0627\u0628 \u0648\u0635\u0644\u0627\u062D\u064A\u0627\u062A\u0647." };
    if (error.code === "ACCOUNT_BLOCKED" || error.code === "user_banned") return { status: 403, code: "ACCOUNT_BLOCKED", error: "\u0647\u0630\u0627 \u0627\u0644\u062D\u0633\u0627\u0628 \u0645\u0648\u0642\u0648\u0641. \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u0648\u0642\u0639." };
    if (error.code === "email_not_confirmed") return { status: 403, code: "EMAIL_NOT_CONFIRMED", error: "\u064A\u0631\u062C\u0649 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0642\u0628\u0644 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644." };
    if (error.code === "invalid_credentials" || error.code === "invalid_grant") return { status: 401, code: "INVALID_CREDENTIALS", error: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629. \u0627\u0633\u062A\u062E\u062F\u0645 \u0628\u064A\u0627\u0646\u0627\u062A \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u062D\u0627\u0644\u064A \u0641\u064A sayarty.store." };
    if (error.status === 401 || error.status === 403) return { status: 401, code: "AUTH_UNAUTHORIZED", error: "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644 \u0623\u0648 \u0627\u0646\u062A\u0647\u062A \u0627\u0644\u062C\u0644\u0633\u0629." };
    if (error.status === 429) return { status: 429, code: "AUTH_RATE_LIMITED", error: "\u0637\u0644\u0628\u0627\u062A \u0643\u062B\u064A\u0631\u0629 \u062E\u0644\u0627\u0644 \u0648\u0642\u062A \u0642\u0635\u064A\u0631. \u0627\u0646\u062A\u0638\u0631 \u0642\u0644\u064A\u0644\u0627\u064B \u062B\u0645 \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u0627\u064B." };
    if (error.status >= 500) return { status: 503, code: "AUTH_SERVICE_UNAVAILABLE", error: "\u062E\u062F\u0645\u0629 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0645\u0624\u0642\u062A\u0627\u064B. \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u0627\u064B \u0644\u0627\u062D\u0642\u0627\u064B." };
  }
  return { status: 400, code: "AUTH_REQUEST_REJECTED", error: "\u062A\u0639\u0630\u0651\u0631\u062A \u0645\u0639\u0627\u0644\u062C\u0629 \u0637\u0644\u0628 \u0627\u0644\u062D\u0633\u0627\u0628. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0646\u0645\u0648\u0630\u062C \u0648\u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u0627\u064B." };
}
function isBlocked(status) {
  return ["blocked", "suspended", "disabled", "banned"].includes((status || "").toLowerCase());
}
function toFrontendUser(profile) {
  return {
    id: profile.id,
    openId: profile.id,
    name: profile.name,
    email: profile.email,
    phone: profile.phone,
    loginMethod: "supabase",
    role: profile.role || "user",
    blocked: isBlocked(profile.status),
    createdAt: profile.created_at
  };
}
function bearerToken(req) {
  const authorization = req.header("authorization");
  if (authorization?.startsWith("Bearer ")) {
    const token = authorization.slice("Bearer ".length).trim();
    if (token && token.length <= 16384) return token;
  }
  return readSupabaseCookie(req, "session");
}
function refreshToken(req, body) {
  const parsedBody = z3.object({ refreshToken: z3.string().min(1).max(16384).optional() }).passthrough().safeParse(body);
  if (parsedBody.success && parsedBody.data.refreshToken) return parsedBody.data.refreshToken;
  return readSupabaseCookie(req, "refresh");
}
async function currentProfile(authUser, accessToken) {
  const rows = await supabaseJson(
    `/rest/v1/users?select=id,name,email,phone,role,status,created_at&id=eq.${encodeURIComponent(authUser.id)}&limit=1`,
    { method: "GET" },
    accessToken
  );
  const profile = rows[0];
  if (!profile) throw new SupabaseRequestError("\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0645\u0644\u0641 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645", 403, "PROFILE_UNAVAILABLE");
  return profile;
}
async function requireSupabaseIdentity(req, requireAdmin = false) {
  if (!isSupabaseConfigured()) throw new TRPCError3({ code: "PRECONDITION_FAILED", message: "Supabase \u063A\u064A\u0631 \u0645\u0647\u064A\u0623" });
  const accessToken = bearerToken(req);
  if (!accessToken) throw new TRPCError3({ code: "UNAUTHORIZED", message: "\u064A\u0631\u062C\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644" });
  try {
    const authUser = await supabaseGetUser(accessToken);
    const profile = await currentProfile(authUser, accessToken);
    if (isBlocked(profile.status)) throw new TRPCError3({ code: "FORBIDDEN", message: "\u0647\u0630\u0627 \u0627\u0644\u062D\u0633\u0627\u0628 \u0645\u0648\u0642\u0648\u0641" });
    if (requireAdmin && profile.role !== "admin") {
      throw new TRPCError3({ code: "FORBIDDEN", message: "\u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0644\u0644\u0645\u0634\u0631\u0641\u064A\u0646 \u0641\u0642\u0637" });
    }
    return { authUser, profile, accessToken, user: toFrontendUser(profile) };
  } catch (error) {
    if (error instanceof TRPCError3) throw error;
    throw new TRPCError3({
      code: error instanceof SupabaseRequestError && error.status >= 500 ? "SERVICE_UNAVAILABLE" : "UNAUTHORIZED",
      message: error instanceof SupabaseRequestError && error.status >= 500 ? "\u062E\u062F\u0645\u0629 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629" : "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u062C\u0644\u0633\u0629 \u0623\u0648 \u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647\u0627"
    });
  }
}
async function getSupabaseIdentity(req) {
  try {
    return await requireSupabaseIdentity(req);
  } catch {
    return null;
  }
}
function cookieOptions(req) {
  return supabaseCookieOptions(req);
}
function setSessionCookies(req, res, session) {
  const options = cookieOptions(req);
  const names = supabaseCookieNames(req);
  const maxAge = Math.max(1, Number(session.expires_in || 60 * 60)) * 1e3;
  res.cookie(names.access, session.access_token, { ...options, maxAge });
  res.cookie(names.refresh, session.refresh_token, { ...options, maxAge: 1e3 * 60 * 60 * 24 * 30 });
}
function clearSupabaseSessionCookies(req, res) {
  const options = cookieOptions(req);
  const names = supabaseCookieNames(req);
  res.clearCookie(names.access, { ...options, maxAge: -1 });
  res.clearCookie(names.refresh, { ...options, maxAge: -1 });
}
function nativeSessionBody(session, user, platform) {
  const result = { user };
  if (platform === "native") {
    result.accessToken = session.access_token;
    result.refreshToken = session.refresh_token;
    result.expiresAt = session.expires_at ?? Math.floor(Date.now() / 1e3) + Number(session.expires_in || 0);
  }
  return result;
}
async function identityFromSession(session) {
  const authUser = session.user ?? await supabaseGetUser(session.access_token);
  const profile = await currentProfile(authUser, session.access_token);
  if (isBlocked(profile.status)) throw new SupabaseRequestError("\u0627\u0644\u062D\u0633\u0627\u0628 \u0645\u0648\u0642\u0648\u0641", 403, "ACCOUNT_BLOCKED");
  return { authUser, profile, accessToken: session.access_token, user: toFrontendUser(profile) };
}
async function revokeSupabaseSession(req) {
  const token = bearerToken(req);
  if (!token || !isSupabaseConfigured()) return;
  try {
    await supabaseFetch("/auth/v1/logout?scope=local", { method: "POST" }, token);
  } catch {
  }
}
function registerSupabaseAuthRoutes(app) {
  app.get("/api/auth/provider", (_req, res) => {
    res.json({
      provider: "supabase",
      websiteUrl: "https://sayarty.store",
      unsupportedCarFields: ["location", "transmission", "fuel", "condition"],
      extendedSettings: false
    });
  });
  app.get("/api/auth/session/transport", (req, res) => {
    const challenge = randomBytes2(16).toString("hex");
    res.setHeader("Cache-Control", "no-store");
    res.cookie(supabaseCookieNames(req).probe, challenge, { ...cookieOptions(req), maxAge: 6e4 });
    res.json({ challenge });
  });
  app.post("/api/auth/session/transport", (req, res) => {
    const parsed = z3.object({ challenge: z3.string().regex(/^[a-f0-9]{32}$/) }).strict().safeParse(req.body);
    const persisted = parsed.success && readSupabaseCookie(req, "transport") === parsed.data.challenge;
    res.setHeader("Cache-Control", "no-store");
    res.clearCookie(supabaseCookieNames(req).probe, cookieOptions(req));
    res.json({ persisted: Boolean(persisted) });
  });
  app.post("/api/auth/local-login", async (req, res) => {
    const parsed = z3.object({ email: emailSchema, password: z3.string().min(1).max(256), platform: z3.string().optional() }).strict().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629" });
      return;
    }
    try {
      const session = await supabaseJson("/auth/v1/token?grant_type=password", {
        method: "POST",
        body: JSON.stringify({ email: parsed.data.email.toLowerCase(), password: parsed.data.password })
      });
      const identity = await identityFromSession(session);
      setSessionCookies(req, res, session);
      res.json(nativeSessionBody(session, identity.user, parsed.data.platform));
    } catch (error) {
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.post("/api/auth/session/refresh", async (req, res) => {
    const token = refreshToken(req, req.body);
    if (!token) {
      res.status(401).json({ error: "\u062C\u0644\u0633\u0629 \u0627\u0644\u062A\u062C\u062F\u064A\u062F \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629" });
      return;
    }
    try {
      const session = await supabaseJson("/auth/v1/token?grant_type=refresh_token", {
        method: "POST",
        body: JSON.stringify({ refresh_token: token })
      });
      const identity = await identityFromSession(session);
      setSessionCookies(req, res, session);
      const platform = z3.object({ platform: z3.string().optional() }).passthrough().safeParse(req.body).data?.platform;
      res.json(nativeSessionBody(session, identity.user, platform));
    } catch (error) {
      clearSupabaseSessionCookies(req, res);
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.post("/api/auth/register/request", async (req, res) => {
    const parsed = z3.object({ email: emailSchema, name: nameSchema, password: passwordSchema, platform: z3.string().optional() }).strict().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0644\u0628\u0631\u064A\u062F \u0648\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 8 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644" });
      return;
    }
    try {
      await supabaseAuthJson("signup", { email: parsed.data.email.toLowerCase(), password: parsed.data.password, data: { name: parsed.data.name } });
      res.json({ ok: true });
    } catch (error) {
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.post("/api/auth/register/verify", async (req, res) => {
    const parsed = z3.object({ email: emailSchema, code: codeSchema, platform: z3.string().optional() }).strict().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u0627\u0644\u0635\u062D\u064A\u062D" });
      return;
    }
    try {
      const session = await supabaseAuthJson("verify", { type: "signup", email: parsed.data.email.toLowerCase(), token: parsed.data.code });
      const identity = await identityFromSession(session);
      setSessionCookies(req, res, session);
      res.json(nativeSessionBody(session, identity.user, parsed.data.platform));
    } catch (error) {
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.post("/api/auth/password/request", async (req, res) => {
    const parsed = z3.object({ email: emailSchema, platform: z3.string().optional() }).strict().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0628\u0631\u064A\u062F\u0627\u064B \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A\u0627\u064B \u0635\u0627\u0644\u062D\u0627\u064B" });
      return;
    }
    try {
      await supabaseAuthJson("recover", { email: parsed.data.email.toLowerCase() });
      res.json({ ok: true });
    } catch (error) {
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.post("/api/auth/password/reset", async (req, res) => {
    const parsed = z3.object({ email: emailSchema, code: codeSchema, password: passwordSchema, platform: z3.string().optional() }).strict().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0631\u0645\u0632 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629" });
      return;
    }
    try {
      const session = await supabaseAuthJson("verify", { type: "recovery", email: parsed.data.email.toLowerCase(), token: parsed.data.code });
      await supabaseFetch("/auth/v1/user", { method: "PUT", body: JSON.stringify({ password: parsed.data.password }) }, session.access_token);
      const identity = await identityFromSession(session);
      setSessionCookies(req, res, session);
      res.json({ ok: true, ...nativeSessionBody(session, identity.user, parsed.data.platform) });
    } catch (error) {
      const result = authError(error);
      res.status(result.status).json({ error: result.error, code: result.code });
    }
  });
  app.get("/api/auth/me", async (req, res) => {
    const identity = await getSupabaseIdentity(req);
    if (!identity) {
      res.status(401).json({ error: "Not authenticated", user: null });
      return;
    }
    res.json({ user: identity.user });
  });
  app.post("/api/auth/logout", async (req, res) => {
    await revokeSupabaseSession(req);
    clearSupabaseSessionCookies(req, res);
    res.json({ success: true });
  });
}
async function updateSupabaseProfile(req, input) {
  const identity = await requireSupabaseIdentity(req);
  const requestedEmail = input.email.trim().toLowerCase();
  let emailChangeRequested = false;
  if (requestedEmail !== (identity.authUser.email || "").toLowerCase()) {
    await supabaseFetch("/auth/v1/user", { method: "PUT", body: JSON.stringify({ email: requestedEmail }) }, identity.accessToken);
    emailChangeRequested = true;
  }
  const rows = await supabaseJson(
    `/rest/v1/users?id=eq.${encodeURIComponent(identity.profile.id)}&select=id,name,email,phone,role,status,created_at`,
    { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ name: input.name.trim(), phone: input.phone.trim() }) },
    identity.accessToken
  );
  const profile = rows[0];
  if (!profile) throw new TRPCError3({ code: "FORBIDDEN", message: "\u0644\u0645 \u062A\u064F\u062D\u0641\u0638 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0627\u0644\u062D\u0633\u0627\u0628 \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639" });
  return { ...toFrontendUser(profile), ...emailChangeRequested ? { emailChangeRequested: true } : {} };
}

// server/supabase-market.ts
import { TRPCError as TRPCError5 } from "@trpc/server";
import { z as z5 } from "zod";

// shared/market.ts
var BRANDS = {
  "\u062A\u0648\u064A\u0648\u062A\u0627": ["\u0644\u0627\u0646\u062F \u0643\u0631\u0648\u0632\u0631", "\u0628\u0631\u0627\u062F\u0648", "\u0643\u0627\u0645\u0631\u064A", "\u0643\u0648\u0631\u0648\u0644\u0627", "\u0647\u0627\u064A\u0644\u0643\u0633", "\u0631\u0627\u0641 \u0641\u0648\u0631", "\u0623\u0641\u0627\u0644\u0648\u0646"],
  "\u0644\u0643\u0632\u0633": ["LX 600", "LX 570", "ES 350", "RX 350", "IS 300", "GX 460"],
  "\u0645\u0631\u0633\u064A\u062F\u0633": ["E 200", "E 300", "C 200", "S 500", "G 63", "GLC 300"],
  "\u0646\u064A\u0633\u0627\u0646": ["\u0628\u0627\u062A\u0631\u0648\u0644", "\u0623\u0644\u062A\u064A\u0645\u0627", "\u0635\u0646\u064A", "\u0625\u0643\u0633 \u062A\u0631\u064A\u0644", "\u0628\u0627\u062B\u0641\u0627\u064A\u0646\u062F\u0631"],
  "\u0628\u064A \u0625\u0645 \u062F\u0628\u0644\u064A\u0648": ["520i", "530i", "X5", "X6", "740i"],
  "\u0643\u064A\u0627": ["\u0633\u0628\u0648\u0631\u062A\u0627\u062C", "K5", "\u0633\u064A\u0631\u0627\u062A\u0648", "\u0633\u0648\u0631\u064A\u0646\u062A\u0648"],
  "\u0647\u064A\u0648\u0646\u062F\u0627\u064A": ["\u062A\u0648\u0633\u0627\u0646", "\u0633\u0648\u0646\u0627\u062A\u0627", "\u0625\u0644\u0646\u062A\u0631\u0627", "\u0633\u0627\u0646\u062A\u0627\u0641\u064A"],
  "\u0634\u064A\u0641\u0631\u0648\u0644\u064A\u0647": ["\u062A\u0627\u0647\u0648", "\u0633\u0648\u0628\u0631\u0628\u0627\u0646", "\u0633\u064A\u0644\u0641\u0631\u0627\u062F\u0648", "\u0645\u0627\u0644\u064A\u0628\u0648"],
  "\u0641\u0648\u0631\u062F": ["\u0625\u0643\u0633\u0628\u0644\u0648\u0631\u0631", "\u0625\u0643\u0633\u0628\u064A\u062F\u064A\u0634\u0646", "\u0645\u0648\u0633\u062A\u0627\u0646\u062C", "F-150"],
  "\u0628\u0648\u0631\u0634": ["\u0643\u0627\u064A\u064A\u0646", "\u0645\u0627\u0643\u0627\u0646", "911", "\u0628\u0627\u0646\u0627\u0645\u064A\u0631\u0627"],
  "\u0644\u0627\u0646\u062F \u0631\u0648\u0641\u0631": ["\u0631\u0646\u062C \u0631\u0648\u0641\u0631", "\u062F\u064A\u0641\u0646\u062F\u0631", "\u062F\u064A\u0633\u0643\u0641\u0631\u064A"],
  "\u062C\u064A \u0625\u0645 \u0633\u064A": ["\u064A\u0648\u0643\u0648\u0646", "\u0633\u064A\u064A\u0631\u0627", "\u0623\u0643\u0627\u062F\u064A\u0627"]
};
var CURRENCIES = [
  { code: "KWD", label: "\u062F\u064A\u0646\u0627\u0631 \u0643\u0648\u064A\u062A\u064A", symbol: "\u062F.\u0643" },
  { code: "SAR", label: "\u0631\u064A\u0627\u0644 \u0633\u0639\u0648\u062F\u064A", symbol: "\u0631.\u0633" },
  { code: "AED", label: "\u062F\u0631\u0647\u0645 \u0625\u0645\u0627\u0631\u0627\u062A\u064A", symbol: "\u062F.\u0625" },
  { code: "QAR", label: "\u0631\u064A\u0627\u0644 \u0642\u0637\u0631\u064A", symbol: "\u0631.\u0642" },
  { code: "BHD", label: "\u062F\u064A\u0646\u0627\u0631 \u0628\u062D\u0631\u064A\u0646\u064A", symbol: "\u062F.\u0628" },
  { code: "OMR", label: "\u0631\u064A\u0627\u0644 \u0639\u064F\u0645\u0627\u0646\u064A", symbol: "\u0631.\u0639" }
];
var DEFAULT_SETTINGS = {
  brands: BRANDS,
  currencies: CURRENCIES.map((x) => x.code),
  terms: "\u0623\u0642\u0631 \u0628\u0623\u0646 \u062C\u0645\u064A\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0635\u062D\u064A\u062D\u0629\u060C \u0648\u0623\u0646\u0646\u064A \u0645\u0627\u0644\u0643 \u0627\u0644\u0633\u064A\u0627\u0631\u0629 \u0623\u0648 \u0645\u062E\u0648\u0651\u0644 \u0628\u0628\u064A\u0639\u0647\u0627. \u0644\u0627 \u0623\u0631\u0641\u0639 \u0635\u0648\u0631\u0627\u064B \u0644\u0627 \u0623\u0645\u0644\u0643 \u062D\u0642 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0648\u0644\u0627 \u0623\u0646\u0634\u0631 \u0645\u062D\u062A\u0648\u0649 \u0645\u0636\u0644\u0644\u0627\u064B. \u064A\u062E\u0636\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u0648\u064A\u062D\u0642 \u0644\u0644\u0625\u062F\u0627\u0631\u0629 \u0631\u0641\u0636 \u0627\u0644\u0645\u062E\u0627\u0644\u0641. \u0644\u0627 \u062A\u0636\u0645\u0646 \u0627\u0644\u0645\u0646\u0635\u0629 \u062D\u0627\u0644\u0629 \u0627\u0644\u0633\u064A\u0627\u0631\u0629 \u0623\u0648 \u0635\u062D\u0629 \u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0629\u060C \u0648\u064A\u064F\u0646\u0635\u062D \u0628\u0627\u0644\u0641\u062D\u0635 \u0642\u0628\u0644 \u0627\u0644\u0634\u0631\u0627\u0621 \u0648\u0639\u062F\u0645 \u062F\u0641\u0639 \u0639\u0631\u0628\u0648\u0646 \u0642\u0628\u0644 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0628\u0627\u0626\u0639.",
  contactEmail: "",
  contactPhone: "",
  whatsapp: "",
  paypalEnabled: false,
  paypalUrl: "",
  westernEnabled: false,
  westernInstructions: "",
  featuredPrice: 5,
  featuredDays: 7
};

// server/market-router.ts
import { createHash as createHash2, randomUUID as randomUUID2 } from "node:crypto";
import { and as and2, desc, eq as eq3, gt as gt2, inArray, sql } from "drizzle-orm";
import { TRPCError as TRPCError4 } from "@trpc/server";
import { z as z4 } from "zod";

// server/storage.ts
function getForgeConfig() {
  const forgeUrl = ENV.forgeApiUrl;
  const forgeKey = ENV.forgeApiKey;
  if (!forgeUrl || !forgeKey) {
    throw new Error(
      "Storage config missing: set BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY"
    );
  }
  return { forgeUrl: forgeUrl.replace(/\/+$/, ""), forgeKey };
}
function normalizeKey(relKey) {
  return relKey.replace(/^\/+/, "");
}
function appendHashSuffix(relKey) {
  const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  const lastDot = relKey.lastIndexOf(".");
  if (lastDot === -1) return `${relKey}_${hash}`;
  return `${relKey.slice(0, lastDot)}_${hash}${relKey.slice(lastDot)}`;
}
async function storagePut(relKey, data, contentType = "application/octet-stream", options = {}) {
  const { forgeUrl, forgeKey } = getForgeConfig();
  const normalizedKey = normalizeKey(relKey);
  const key = options.unique === false ? normalizedKey : appendHashSuffix(normalizedKey);
  const presignUrl = new URL("v1/storage/presign/put", forgeUrl + "/");
  presignUrl.searchParams.set("path", key);
  const presignResp = await fetch(presignUrl, {
    headers: { Authorization: `Bearer ${forgeKey}` }
  });
  if (!presignResp.ok) {
    const msg = await presignResp.text().catch(() => presignResp.statusText);
    throw new Error(`Storage presign failed (${presignResp.status}): ${msg}`);
  }
  const { url: s3Url } = await presignResp.json();
  if (!s3Url) throw new Error("Forge returned empty presign URL");
  const blob = typeof data === "string" ? new Blob([data], { type: contentType }) : new Blob([data], { type: contentType });
  const uploadResp = await fetch(s3Url, {
    method: "PUT",
    headers: { "Content-Type": contentType },
    body: blob
  });
  if (!uploadResp.ok) {
    throw new Error(`Storage upload to S3 failed (${uploadResp.status})`);
  }
  return { key, url: `/manus-storage/${key}` };
}

// server/market-router.ts
var MAX_IMAGE_BYTES = 5 * 1024 * 1024;
var MAX_IMAGE_BASE64_CHARS = Math.ceil(MAX_IMAGE_BYTES / 3) * 4 + 128;
var CONTACT_RATE_LIMIT = 3;
var CONTACT_RATE_WINDOW_MS = 60 * 60 * 1e3;
var ONE_DAY_MS = 24 * 60 * 60 * 1e3;
var imageMimeSchema = z4.enum(["image/jpeg", "image/png", "image/webp"]);
var nonEmpty = (max) => z4.string().trim().min(1).max(max);
var optionalText = (max) => z4.string().trim().max(max);
var phoneSchema = z4.string().trim().min(7).max(32).regex(/^\+?[0-9][0-9\s()-]{5,30}$/, "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
var emailSchema2 = z4.string().trim().email().max(320);
var optionalEmailSchema = z4.string().trim().max(320).refine((value) => value === "" || emailSchema2.safeParse(value).success, "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
var settingsSchema = z4.object({
  brands: z4.record(
    nonEmpty(80),
    z4.array(nonEmpty(120)).min(1).max(80).refine((models) => new Set(models).size === models.length)
  ).refine((brands) => Object.keys(brands).length > 0 && Object.keys(brands).length <= 80),
  currencies: z4.array(z4.string().trim().regex(/^[A-Z]{3}$/)).min(1).max(20).refine((currencies) => new Set(currencies).size === currencies.length, "\u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0645\u0643\u0631\u0631\u0629"),
  terms: nonEmpty(10).max(8e3),
  contactEmail: optionalEmailSchema,
  contactPhone: optionalText(32),
  whatsapp: optionalText(64),
  paypalEnabled: z4.boolean(),
  paypalUrl: optionalText(512),
  westernEnabled: z4.boolean(),
  westernInstructions: optionalText(8e3),
  featuredPrice: z4.number().finite().min(0).max(1e7),
  featuredDays: z4.number().int().min(1).max(365)
}).strict();
var listingInputSchema = z4.object({
  brand: nonEmpty(80),
  model: nonEmpty(120),
  year: z4.number().int(),
  color: nonEmpty(64),
  price: z4.number().finite().positive().max(1e8),
  currency: z4.string().trim().regex(/^[A-Z]{3}$/),
  mileage: z4.number().int().min(0).max(2e6),
  location: nonEmpty(120),
  description: nonEmpty(10).max(1e4),
  transmission: nonEmpty(64),
  fuel: nonEmpty(64),
  condition: nonEmpty(64),
  images: z4.array(z4.string().trim().max(768).regex(/^\/manus-storage\/cars\/[0-9]+\//, "\u0645\u0633\u0627\u0631 \u0627\u0644\u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D")).min(1).max(6).refine((images) => new Set(images).size === images.length, "\u0627\u0644\u0635\u0648\u0631 \u0645\u0643\u0631\u0631\u0629"),
  termsAccepted: z4.literal(true)
}).strict();
var idSchema = z4.object({ id: z4.number().int().positive() }).strict();
function badRequest(message) {
  throw new TRPCError4({ code: "BAD_REQUEST", message });
}
function notFound(message = "\u0627\u0644\u0639\u0646\u0635\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F") {
  throw new TRPCError4({ code: "NOT_FOUND", message });
}
async function requireDb2() {
  const db = await getDb();
  if (!db) {
    throw new TRPCError4({ code: "INTERNAL_SERVER_ERROR", message: "\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629" });
  }
  return db;
}
function cloneDefaults() {
  return {
    ...DEFAULT_SETTINGS,
    brands: Object.fromEntries(
      Object.entries(DEFAULT_SETTINGS.brands).map(([brand, models]) => [brand, [...models]])
    ),
    currencies: [...DEFAULT_SETTINGS.currencies]
  };
}
function isTrustedPaypalUrl(value) {
  if (!value) return false;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) return false;
    const host = url.hostname.toLowerCase();
    return host === "paypal.com" || host.endsWith(".paypal.com") || host === "paypal.me" || host.endsWith(".paypal.me");
  } catch {
    return false;
  }
}
function validateSettings(input) {
  const parsed = settingsSchema.safeParse(input);
  if (!parsed.success) {
    badRequest("\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0633\u0648\u0642 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629");
  }
  const settings = parsed.data;
  if (!settings.currencies.includes("KWD")) {
    badRequest("\u064A\u062C\u0628 \u0623\u0646 \u062A\u0628\u0642\u0649 \u0639\u0645\u0644\u0629 KWD \u0645\u0641\u0639\u0644\u0629");
  }
  if (settings.paypalUrl && !isTrustedPaypalUrl(settings.paypalUrl)) {
    badRequest("\u0631\u0627\u0628\u0637 PayPal \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 HTTPS \u0645\u0646 paypal.com \u0623\u0648 paypal.me");
  }
  if (settings.paypalEnabled && !settings.paypalUrl) {
    badRequest("\u0623\u062F\u062E\u0644 \u0631\u0627\u0628\u0637 PayPal \u0642\u0628\u0644 \u062A\u0641\u0639\u064A\u0644\u0647");
  }
  if (settings.westernEnabled && !settings.westernInstructions) {
    badRequest("\u0623\u062F\u062E\u0644 \u062A\u0639\u0644\u064A\u0645\u0627\u062A Western Union \u0642\u0628\u0644 \u062A\u0641\u0639\u064A\u0644\u0647");
  }
  return settings;
}
async function loadSettings(db) {
  const row = (await db.select().from(marketSettings).where(eq3(marketSettings.id, 1)).limit(1))[0];
  if (!row) return cloneDefaults();
  const defaults = cloneDefaults();
  const candidate = {
    ...defaults,
    brands: row.brands ?? defaults.brands,
    currencies: row.currencies ?? defaults.currencies,
    terms: row.terms ?? defaults.terms,
    contactEmail: row.contactEmail ?? defaults.contactEmail,
    contactPhone: row.contactPhone ?? defaults.contactPhone,
    whatsapp: row.whatsapp ?? defaults.whatsapp,
    paypalEnabled: Boolean(row.paypalEnabled),
    paypalUrl: row.paypalUrl ?? defaults.paypalUrl,
    westernEnabled: Boolean(row.westernEnabled),
    westernInstructions: row.westernInstructions ?? defaults.westernInstructions,
    featuredPrice: Number(row.featuredPrice),
    featuredDays: row.featuredDays
  };
  const parsed = settingsSchema.safeParse(candidate);
  return parsed.success ? parsed.data : defaults;
}
function assertListingAllowed(input, settings) {
  const maxYear = (/* @__PURE__ */ new Date()).getFullYear() + 1;
  if (input.year < 1886 || input.year > maxYear) {
    badRequest("\u0633\u0646\u0629 \u0627\u0644\u0635\u0646\u0639 \u063A\u064A\u0631 \u0645\u0646\u0637\u0642\u064A\u0629");
  }
  const models = settings.brands[input.brand];
  if (!models || !models.includes(input.model)) {
    badRequest("\u0627\u0644\u0639\u0644\u0627\u0645\u0629 \u0623\u0648 \u0627\u0644\u0645\u0648\u062F\u064A\u0644 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0641\u064A \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0633\u0648\u0642");
  }
  if (!settings.currencies.includes(input.currency)) {
    badRequest("\u0627\u0644\u0639\u0645\u0644\u0629 \u063A\u064A\u0631 \u0645\u0641\u0639\u0644\u0629 \u0641\u064A \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0633\u0648\u0642");
  }
}
async function assertOwnedUploads(db, userId, imageUrls) {
  const uploaded = await db.select({ url: uploadedAssets.url }).from(uploadedAssets).where(and2(eq3(uploadedAssets.userId, userId), inArray(uploadedAssets.url, imageUrls)));
  if (uploaded.length !== imageUrls.length) {
    badRequest("\u0643\u0644 \u0635\u0648\u0631\u0629 \u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0645\u0631\u0641\u0648\u0639\u0629 \u0645\u0646 \u062D\u0633\u0627\u0628\u0643 \u0639\u0628\u0631 \u0627\u0644\u0645\u0646\u0635\u0629");
  }
}
function activeFeatured(listing) {
  return Boolean(listing.featured) && Boolean(listing.featuredUntil && listing.featuredUntil.getTime() > Date.now());
}
function toListing(listing, seller) {
  return {
    id: listing.id,
    userId: listing.userId,
    brand: listing.brand,
    model: listing.model,
    year: listing.year,
    color: listing.color,
    price: String(listing.price),
    currency: listing.currency,
    mileage: listing.mileage,
    location: listing.location,
    description: listing.description,
    transmission: listing.transmission,
    fuel: listing.fuel,
    condition: listing.condition,
    images: Array.isArray(listing.images) ? listing.images : [],
    status: listing.status,
    featured: activeFeatured(listing),
    featuredUntil: listing.featuredUntil,
    sellerName: seller.name?.trim() || "\u0645\u0633\u062A\u062E\u062F\u0645",
    sellerPhone: seller.phone ?? "",
    createdAt: listing.createdAt,
    rejectionReason: listing.rejectionReason
  };
}
async function findListingWithSeller(db, id) {
  return (await db.select({ listing: listings, seller: users }).from(listings).innerJoin(users, eq3(listings.userId, users.id)).where(eq3(listings.id, id)).limit(1))[0];
}
function clientIpHash(req) {
  const forwarded = req.headers["x-forwarded-for"];
  const candidate = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
  const ip = (candidate || req.ip || "unknown").trim().slice(0, 128);
  return createHash2("sha256").update(`${process.env.MANUS_JWT_SECRET ?? "market"}:${ip}`).digest("hex");
}
function decodeUploadedImage(base64, claimedMime) {
  const dataUri = /^data:([^;]+);base64,/i.exec(base64);
  if (dataUri && dataUri[1].toLowerCase() !== claimedMime) {
    badRequest("\u0646\u0648\u0639 \u0645\u0644\u0641 \u0627\u0644\u0635\u0648\u0631\u0629 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0631\u0641\u0648\u0639\u0629");
  }
  const encoded = (dataUri ? base64.slice(dataUri[0].length) : base64).replace(/\s/g, "");
  if (!encoded || encoded.length > MAX_IMAGE_BASE64_CHARS || !/^[A-Za-z0-9+/]*={0,2}$/.test(encoded) || encoded.length % 4 === 1) {
    badRequest("\u062A\u0631\u0645\u064A\u0632 \u0627\u0644\u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D \u0623\u0648 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D");
  }
  const bytes = Buffer.from(encoded, "base64");
  const canonical = bytes.toString("base64").replace(/=+$/, "");
  if (!bytes.length || canonical !== encoded.replace(/=+$/, "") || bytes.length > MAX_IMAGE_BYTES) {
    badRequest("\u062A\u0631\u0645\u064A\u0632 \u0627\u0644\u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D \u0623\u0648 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D");
  }
  let detected = null;
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) {
    detected = { mime: "image/jpeg" };
  } else if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    detected = { mime: "image/png" };
  } else if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP") {
    detected = { mime: "image/webp" };
  }
  if (!detected || detected.mime !== claimedMime) {
    badRequest("\u0645\u0644\u0641 \u0627\u0644\u0635\u0648\u0631\u0629 \u0644\u064A\u0633 JPEG \u0623\u0648 PNG \u0623\u0648 WEBP \u0645\u0637\u0627\u0628\u0642\u0627\u064B \u0644\u0644\u0646\u0648\u0639 \u0627\u0644\u0645\u0631\u0633\u0644");
  }
  return { bytes, detected };
}
var marketRouter = router({
  settings: publicProcedure.query(async () => loadSettings(await requireDb2())),
  list: publicProcedure.query(async () => {
    const db = await requireDb2();
    const now = /* @__PURE__ */ new Date();
    const rows = await db.select({ listing: listings, seller: users }).from(listings).innerJoin(users, eq3(listings.userId, users.id)).where(eq3(listings.status, "approved")).orderBy(
      desc(sql`case when ${listings.featured} = 1 and ${listings.featuredUntil} > ${now} then 1 else 0 end`),
      desc(listings.createdAt)
    );
    return rows.map(({ listing, seller }) => toListing(listing, seller));
  }),
  detail: publicProcedure.input(idSchema).query(async ({ ctx, input }) => {
    const db = await requireDb2();
    const row = await findListingWithSeller(db, input.id);
    if (!row) notFound();
    const mayViewUnapproved = ctx.user && (ctx.user.id === row.listing.userId || ctx.user.role === "admin");
    if (row.listing.status !== "approved" && !mayViewUnapproved) notFound();
    return toListing(row.listing, row.seller);
  }),
  me: protectedProcedure.query(async ({ ctx }) => {
    const db = await requireDb2();
    const ownListings = await db.select({ listing: listings, seller: users }).from(listings).innerJoin(users, eq3(listings.userId, users.id)).where(eq3(listings.userId, ctx.user.id)).orderBy(desc(listings.createdAt));
    const requests = await db.select({
      id: featuredRequests.id,
      listingId: featuredRequests.listingId,
      method: featuredRequests.method,
      reference: featuredRequests.reference,
      status: featuredRequests.status,
      createdAt: featuredRequests.createdAt
    }).from(featuredRequests).where(eq3(featuredRequests.userId, ctx.user.id)).orderBy(desc(featuredRequests.createdAt));
    return {
      ...ctx.user,
      user: ctx.user,
      listings: ownListings.map(({ listing, seller }) => toListing(listing, seller)),
      featuredRequests: requests
    };
  }),
  profile: protectedProcedure.input(z4.object({ name: nonEmpty(100), email: emailSchema2, phone: phoneSchema }).strict()).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    await db.update(users).set({ name: input.name, email: input.email, phone: input.phone }).where(eq3(users.id, ctx.user.id));
    const user = (await db.select().from(users).where(eq3(users.id, ctx.user.id)).limit(1))[0];
    if (!user) notFound("\u0627\u0644\u062D\u0633\u0627\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    return user;
  }),
  create: protectedProcedure.input(listingInputSchema).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const user = (await db.select().from(users).where(eq3(users.id, ctx.user.id)).limit(1))[0];
    if (!user?.phone?.trim()) badRequest("\u0623\u0636\u0641 \u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0635\u0627\u0644\u062D\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0642\u0628\u0644 \u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646");
    const settings = await loadSettings(db);
    assertListingAllowed(input, settings);
    await assertOwnedUploads(db, ctx.user.id, input.images);
    const inserted = await db.insert(listings).values({
      userId: ctx.user.id,
      brand: input.brand,
      model: input.model,
      year: input.year,
      color: input.color,
      price: input.price.toFixed(2),
      currency: input.currency,
      mileage: input.mileage,
      location: input.location,
      description: input.description,
      transmission: input.transmission,
      fuel: input.fuel,
      condition: input.condition,
      images: input.images,
      status: "pending",
      featured: false
    }).$returningId();
    return { id: inserted[0].id };
  }),
  update: protectedProcedure.input(idSchema.extend(listingInputSchema.shape).strict()).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const existing = (await db.select().from(listings).where(eq3(listings.id, input.id)).limit(1))[0];
    if (!existing || existing.userId !== ctx.user.id) notFound();
    if (existing.status === "archived") badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644 \u0625\u0639\u0644\u0627\u0646 \u0645\u0624\u0631\u0634\u0641");
    const user = (await db.select().from(users).where(eq3(users.id, ctx.user.id)).limit(1))[0];
    if (!user?.phone?.trim()) badRequest("\u0623\u0636\u0641 \u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0635\u0627\u0644\u062D\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0642\u0628\u0644 \u0625\u0639\u0627\u062F\u0629 \u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646");
    const settings = await loadSettings(db);
    assertListingAllowed(input, settings);
    await assertOwnedUploads(db, ctx.user.id, input.images);
    await db.update(listings).set({
      brand: input.brand,
      model: input.model,
      year: input.year,
      color: input.color,
      price: input.price.toFixed(2),
      currency: input.currency,
      mileage: input.mileage,
      location: input.location,
      description: input.description,
      transmission: input.transmission,
      fuel: input.fuel,
      condition: input.condition,
      images: input.images,
      status: "pending",
      featured: false,
      featuredUntil: null,
      rejectionReason: null
    }).where(and2(eq3(listings.id, input.id), eq3(listings.userId, ctx.user.id)));
    return { id: input.id, status: "pending" };
  }),
  setSold: protectedProcedure.input(idSchema).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const listing = (await db.select().from(listings).where(eq3(listings.id, input.id)).limit(1))[0];
    if (!listing || listing.userId !== ctx.user.id) notFound();
    if (listing.status !== "approved") badRequest("\u064A\u0645\u0643\u0646 \u062A\u0639\u0644\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629 \u0641\u0642\u0637 \u0639\u0644\u0649 \u0623\u0646\u0647\u0627 \u0645\u0628\u0627\u0639\u0629");
    await db.update(listings).set({ status: "sold", featured: false, featuredUntil: null }).where(and2(eq3(listings.id, input.id), eq3(listings.userId, ctx.user.id), eq3(listings.status, "approved")));
    return { id: input.id, status: "sold" };
  }),
  upload: protectedProcedure.input(z4.object({ base64: z4.string().max(MAX_IMAGE_BASE64_CHARS), mime: z4.string().trim().max(32) }).strict()).mutation(async ({ ctx, input }) => {
    const claimedMime = imageMimeSchema.safeParse(input.mime);
    if (!claimedMime.success) badRequest("\u0646\u0648\u0639 \u0627\u0644\u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645");
    const { bytes, detected } = decodeUploadedImage(input.base64, claimedMime.data);
    const db = await requireDb2();
    const key = `cars/${ctx.user.id}/${randomUUID2()}.jpg`;
    const stored = await storagePut(key, bytes, detected.mime, { unique: false });
    await db.insert(uploadedAssets).values({
      userId: ctx.user.id,
      storageKey: stored.key,
      url: stored.url,
      mime: detected.mime,
      bytes: bytes.length
    });
    return { url: stored.url };
  }),
  featureRequest: protectedProcedure.input(
    z4.object({
      listingId: z4.number().int().positive(),
      method: z4.enum(["paypal", "western"]),
      reference: nonEmpty(256)
    }).strict()
  ).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const listing = (await db.select().from(listings).where(eq3(listings.id, input.listingId)).limit(1))[0];
    if (!listing || listing.userId !== ctx.user.id) notFound();
    if (listing.status !== "approved") badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0637\u0644\u0628 \u062A\u0645\u064A\u064A\u0632 \u0625\u0644\u0627 \u0644\u0625\u0639\u0644\u0627\u0646 \u0645\u0646\u0634\u0648\u0631");
    const settings = await loadSettings(db);
    if (input.method === "paypal" && (!settings.paypalEnabled || !settings.paypalUrl)) {
      badRequest("\u0627\u0644\u062F\u0641\u0639 \u0639\u0628\u0631 PayPal \u063A\u064A\u0631 \u0645\u0641\u0639\u0644");
    }
    if (input.method === "western" && (!settings.westernEnabled || !settings.westernInstructions)) {
      badRequest("Western Union \u063A\u064A\u0631 \u0645\u0641\u0639\u0644");
    }
    const duplicate = await db.select({ id: featuredRequests.id }).from(featuredRequests).where(and2(eq3(featuredRequests.listingId, input.listingId), eq3(featuredRequests.status, "pending"))).limit(1);
    if (duplicate.length) badRequest("\u064A\u0648\u062C\u062F \u0637\u0644\u0628 \u062A\u0645\u064A\u064A\u0632 \u0642\u064A\u062F \u0627\u0644\u0645\u0631\u0627\u062C\u0639\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646");
    const inserted = await db.insert(featuredRequests).values({
      listingId: input.listingId,
      userId: ctx.user.id,
      method: input.method,
      reference: input.reference,
      amount: settings.featuredPrice.toFixed(2),
      duration: settings.featuredDays,
      status: "pending"
    }).$returningId();
    return { id: inserted[0].id, status: "pending" };
  }),
  contact: publicProcedure.input(z4.object({ name: nonEmpty(100), email: emailSchema2, message: nonEmpty(4).max(5e3) }).strict()).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const ipHash = clientIpHash(ctx.req);
    const since = new Date(Date.now() - CONTACT_RATE_WINDOW_MS);
    const recent = await db.select({ id: contactMessages.id }).from(contactMessages).where(and2(eq3(contactMessages.ipHash, ipHash), gt2(contactMessages.createdAt, since))).limit(CONTACT_RATE_LIMIT);
    if (recent.length >= CONTACT_RATE_LIMIT) {
      throw new TRPCError4({ code: "TOO_MANY_REQUESTS", message: "\u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u0627\u064B \u0628\u0639\u062F \u0633\u0627\u0639\u0629" });
    }
    await db.insert(contactMessages).values({ ...input, ipHash });
    return { success: true };
  }),
  adminOverview: adminProcedure.query(async () => {
    const db = await requireDb2();
    const now = /* @__PURE__ */ new Date();
    const [listingRows, userRows, requestRows, messageRows, listingCounts, pendingCounts, featuredCounts, userCounts] = await Promise.all([
      db.select({ listing: listings, seller: users }).from(listings).innerJoin(users, eq3(listings.userId, users.id)).orderBy(desc(listings.createdAt)),
      db.select().from(users).orderBy(desc(users.createdAt)),
      db.select({
        id: featuredRequests.id,
        listingId: featuredRequests.listingId,
        method: featuredRequests.method,
        reference: featuredRequests.reference,
        status: featuredRequests.status,
        createdAt: featuredRequests.createdAt,
        listingTitle: sql`concat(${listings.brand}, ' ', ${listings.model}, ' ', ${listings.year})`,
        userName: users.name,
        amount: featuredRequests.amount,
        duration: featuredRequests.duration
      }).from(featuredRequests).innerJoin(listings, eq3(featuredRequests.listingId, listings.id)).innerJoin(users, eq3(featuredRequests.userId, users.id)).orderBy(desc(featuredRequests.createdAt)),
      db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)),
      db.select({ count: sql`count(*)` }).from(listings),
      db.select({ count: sql`count(*)` }).from(listings).where(eq3(listings.status, "pending")),
      db.select({ count: sql`count(*)` }).from(listings).where(and2(eq3(listings.featured, true), gt2(listings.featuredUntil, now))),
      db.select({ count: sql`count(*)` }).from(users)
    ]);
    return {
      listings: listingRows.map(({ listing, seller }) => toListing(listing, seller)),
      users: userRows,
      requests: requestRows.map((request) => ({ ...request, amount: String(request.amount) })),
      messages: messageRows,
      stats: {
        total: Number(listingCounts[0]?.count ?? 0),
        pending: Number(pendingCounts[0]?.count ?? 0),
        featured: Number(featuredCounts[0]?.count ?? 0),
        users: Number(userCounts[0]?.count ?? 0)
      }
    };
  }),
  moderate: adminProcedure.input(
    z4.object({
      id: z4.number().int().positive(),
      status: z4.enum(["approved", "rejected", "sold"]),
      reason: optionalText(2e3).optional()
    }).strict()
  ).mutation(async ({ input }) => {
    const db = await requireDb2();
    const listing = (await db.select().from(listings).where(eq3(listings.id, input.id)).limit(1))[0];
    if (!listing) notFound();
    await db.update(listings).set({
      status: input.status,
      rejectionReason: input.status === "rejected" ? input.reason || null : null,
      ...input.status === "approved" ? {} : { featured: false, featuredUntil: null }
    }).where(eq3(listings.id, input.id));
    return { id: input.id, status: input.status };
  }),
  deleteListing: adminProcedure.input(idSchema).mutation(async ({ input }) => {
    const db = await requireDb2();
    const listing = (await db.select().from(listings).where(eq3(listings.id, input.id)).limit(1))[0];
    if (!listing) notFound("\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    await db.transaction(async (tx) => {
      await tx.delete(featuredRequests).where(eq3(featuredRequests.listingId, input.id));
      await tx.delete(listings).where(eq3(listings.id, input.id));
    });
    return { id: input.id, deleted: true };
  }),
  featureDecision: adminProcedure.input(
    z4.object({ id: z4.number().int().positive(), approved: z4.boolean(), paymentConfirmed: z4.boolean() }).strict()
  ).mutation(async ({ ctx, input }) => {
    const db = await requireDb2();
    const request = (await db.select().from(featuredRequests).where(eq3(featuredRequests.id, input.id)).limit(1))[0];
    if (!request) notFound("\u0637\u0644\u0628 \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    if (request.status !== "pending") badRequest("\u062A\u0645\u062A \u0645\u0631\u0627\u062C\u0639\u0629 \u0637\u0644\u0628 \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u0645\u0633\u0628\u0642\u0627\u064B");
    const listing = (await db.select().from(listings).where(eq3(listings.id, request.listingId)).limit(1))[0];
    if (!listing || listing.status !== "approved") {
      badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0637\u0644\u0628 \u0644\u0623\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0644\u0645 \u064A\u0639\u062F \u0645\u0646\u0634\u0648\u0631\u0627\u064B");
    }
    if (input.approved && !input.paymentConfirmed) {
      badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u0642\u0628\u0644 \u062A\u0623\u0643\u064A\u062F \u0627\u0644\u062F\u0641\u0639 \u064A\u062F\u0648\u064A\u0627\u064B");
    }
    const now = /* @__PURE__ */ new Date();
    if (input.approved) {
      const featuredUntil = new Date(now.getTime() + request.duration * ONE_DAY_MS);
      await db.update(featuredRequests).set({ status: "approved", decidedAt: now, decidedByUserId: ctx.user.id }).where(and2(eq3(featuredRequests.id, input.id), eq3(featuredRequests.status, "pending")));
      await db.update(listings).set({ featured: true, featuredUntil }).where(and2(eq3(listings.id, listing.id), eq3(listings.status, "approved")));
      return { id: input.id, status: "approved", featuredUntil };
    }
    await db.update(featuredRequests).set({ status: "rejected", decidedAt: now, decidedByUserId: ctx.user.id }).where(and2(eq3(featuredRequests.id, input.id), eq3(featuredRequests.status, "pending")));
    return { id: input.id, status: "rejected" };
  }),
  userStatus: adminProcedure.input(z4.object({ id: z4.number().int().positive(), blocked: z4.boolean() }).strict()).mutation(async ({ ctx, input }) => {
    if (input.id === ctx.user.id) badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u062D\u0633\u0627\u0628\u0643");
    const db = await requireDb2();
    const target = (await db.select().from(users).where(eq3(users.id, input.id)).limit(1))[0];
    if (!target) notFound("\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    if (target.role === "admin") badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628 \u0625\u062F\u0627\u0631\u064A");
    await db.update(users).set({ blocked: input.blocked }).where(eq3(users.id, input.id));
    return { id: input.id, blocked: input.blocked };
  }),
  deleteUser: adminProcedure.input(idSchema).mutation(async ({ ctx, input }) => {
    if (input.id === ctx.user.id) badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u062D\u0630\u0641 \u062D\u0633\u0627\u0628\u0643 \u0627\u0644\u062D\u0627\u0644\u064A");
    const db = await requireDb2();
    const target = (await db.select().from(users).where(eq3(users.id, input.id)).limit(1))[0];
    if (!target) notFound("\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    if (target.role === "admin") badRequest("\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0630\u0641 \u062D\u0633\u0627\u0628 \u0625\u062F\u0627\u0631\u064A");
    const owned = await db.select({ id: listings.id }).from(listings).where(eq3(listings.userId, input.id));
    await db.transaction(async (tx) => {
      for (const listing of owned) await tx.delete(featuredRequests).where(eq3(featuredRequests.listingId, listing.id));
      await tx.delete(listings).where(eq3(listings.userId, input.id));
      await tx.delete(uploadedAssets).where(eq3(uploadedAssets.userId, input.id));
      await tx.delete(localCredentials).where(eq3(localCredentials.userId, input.id));
      await tx.delete(users).where(eq3(users.id, input.id));
    });
    return { id: input.id, deleted: true };
  }),
  saveSettings: adminProcedure.input(settingsSchema).mutation(async ({ input }) => {
    const db = await requireDb2();
    const settings = validateSettings(input);
    await db.insert(marketSettings).values({
      id: 1,
      brands: settings.brands,
      currencies: settings.currencies,
      terms: settings.terms,
      contactEmail: settings.contactEmail,
      contactPhone: settings.contactPhone,
      whatsapp: settings.whatsapp,
      paypalEnabled: settings.paypalEnabled,
      paypalUrl: settings.paypalUrl,
      westernEnabled: settings.westernEnabled,
      westernInstructions: settings.westernInstructions,
      featuredPrice: settings.featuredPrice.toFixed(2),
      featuredDays: settings.featuredDays
    }).onDuplicateKeyUpdate({
      set: {
        brands: settings.brands,
        currencies: settings.currencies,
        terms: settings.terms,
        contactEmail: settings.contactEmail,
        contactPhone: settings.contactPhone,
        whatsapp: settings.whatsapp,
        paypalEnabled: settings.paypalEnabled,
        paypalUrl: settings.paypalUrl,
        westernEnabled: settings.westernEnabled,
        westernInstructions: settings.westernInstructions,
        featuredPrice: settings.featuredPrice.toFixed(2),
        featuredDays: settings.featuredDays
      }
    });
    return settings;
  })
});

// server/supabase-market.ts
var CAR_FIELDS = "id,user_id,brand,model,year,price,kilometers,color,description,images,currency,status,created_at,is_featured,featured_until,featured_payment_ref";
var USER_FIELDS = "id,name,email,phone,role,status,created_at";
var MAX_IMAGE_BASE64_CHARS2 = Math.ceil(5 * 1024 * 1024 / 3) * 4 + 128;
var FEATURED_DAYS = 30;
var SITE_ADMIN_URL = "https://sayarty.store/admin";
var nonEmpty2 = (max) => z5.string().trim().min(1).max(max);
var optionalText2 = (max) => z5.string().trim().max(max);
var phoneSchema2 = z5.string().trim().min(7).max(32).regex(/^\+?[0-9][0-9\s()-]{5,30}$/, "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
var emailSchema3 = z5.string().trim().email().max(320);
var idValue = z5.union([
  z5.number().int().positive(),
  z5.string().trim().regex(/^(?:[1-9]\d*|[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})$/i, "\u0645\u0639\u0631\u0651\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D")
]);
var idSchema2 = z5.object({ id: idValue }).strict();
var imageMimeSchema2 = z5.enum(["image/jpeg", "image/png", "image/webp"]);
var listingInputSchema2 = z5.object({
  brand: nonEmpty2(80),
  model: nonEmpty2(120),
  year: z5.number().int(),
  color: nonEmpty2(64),
  price: z5.number().finite().positive().max(1e8),
  currency: z5.string().trim().regex(/^[A-Z]{3}$/),
  mileage: z5.number().int().min(0).max(2e6),
  // The following values are accepted for client compatibility, but the verified schema has no columns for them.
  location: optionalText2(120).optional(),
  description: nonEmpty2(10).max(1e4),
  transmission: optionalText2(64).optional(),
  fuel: optionalText2(64).optional(),
  condition: optionalText2(64).optional(),
  images: z5.array(z5.string().url().max(2048)).min(1).max(6).refine((images) => new Set(images).size === images.length, "\u0627\u0644\u0635\u0648\u0631 \u0645\u0643\u0631\u0631\u0629"),
  termsAccepted: z5.literal(true)
}).strict();
var settingsSchema2 = z5.object({
  brands: z5.record(z5.string(), z5.array(z5.string())),
  currencies: z5.array(z5.string()),
  terms: z5.string(),
  contactEmail: z5.string(),
  contactPhone: z5.string(),
  whatsapp: z5.string(),
  paypalEnabled: z5.boolean(),
  paypalUrl: z5.string(),
  westernEnabled: z5.boolean(),
  westernInstructions: z5.string(),
  featuredPrice: z5.number().finite().min(0).max(1e7),
  featuredDays: z5.number().int().min(1).max(365),
  paypalEmail: z5.union([z5.literal(""), z5.string().trim().email().max(320)]).optional()
}).strict();
function badRequest2(message) {
  throw new TRPCError5({ code: "BAD_REQUEST", message });
}
function notFound2(message = "\u0627\u0644\u0639\u0646\u0635\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F") {
  throw new TRPCError5({ code: "NOT_FOUND", message });
}
function idText(value) {
  return String(value);
}
function dateOrNull(value) {
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? date : null;
}
function parseImages(value) {
  if (Array.isArray(value)) return value.filter((item) => typeof item === "string" && item.length <= 2048);
  if (typeof value === "string") {
    try {
      return parseImages(JSON.parse(value));
    } catch {
      return [];
    }
  }
  return [];
}
function isActiveFeatured(car) {
  const until = dateOrNull(car.featured_until);
  return Boolean(car.is_featured && until && until.getTime() > Date.now());
}
function visibleStatus(car) {
  return car.status === "pending_featured" ? "approved" : car.status;
}
function mapCar(car, seller) {
  return {
    id: car.id,
    userId: car.user_id,
    brand: car.brand,
    model: car.model,
    year: Number(car.year),
    color: car.color,
    price: String(car.price),
    currency: car.currency,
    mileage: Number(car.kilometers),
    // These values are intentionally empty: the deployed website schema has no matching columns.
    location: "",
    description: car.description || "",
    transmission: "",
    fuel: "",
    condition: "",
    images: parseImages(car.images),
    status: visibleStatus(car),
    featured: isActiveFeatured(car),
    featuredUntil: car.featured_until,
    sellerName: seller?.name?.trim() || "",
    sellerPhone: seller?.phone || "",
    createdAt: car.created_at,
    rejectionReason: null
  };
}
async function fetchSettings(accessToken) {
  const rows = await supabaseJson(
    "/rest/v1/site_settings?select=id,featured_price,western_union_info,paypal_email,paypal_enabled,western_union_enabled&id=eq.global&limit=1",
    { method: "GET" },
    accessToken
  );
  return rows[0] ?? null;
}
async function loadSettings2(accessToken) {
  const row = await fetchSettings(accessToken);
  return {
    ...DEFAULT_SETTINGS,
    featuredPrice: Number(row?.featured_price ?? DEFAULT_SETTINGS.featuredPrice),
    featuredDays: FEATURED_DAYS,
    paypalEnabled: Boolean(row?.paypal_enabled),
    paypalUrl: "",
    // An email address must never be turned into a guessed PayPal.me URL.
    paypalEmail: row?.paypal_email?.trim() || "",
    westernEnabled: Boolean(row?.western_union_enabled),
    westernInstructions: row?.western_union_info || ""
  };
}
function assertListingValues(input) {
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear() + 1;
  if (input.year < 1886 || input.year > currentYear) badRequest2("\u0633\u0646\u0629 \u0627\u0644\u0635\u0646\u0639 \u063A\u064A\u0631 \u0645\u0646\u0637\u0642\u064A\u0629");
}
async function carById(id, accessToken) {
  const rows = await supabaseJson(`/rest/v1/cars?select=${CAR_FIELDS}&id=eq.${encodeURIComponent(id)}&limit=1`, { method: "GET" }, accessToken);
  return rows[0] ?? null;
}
async function requireOwnedCar(identity, id) {
  const car = await carById(id, identity.accessToken);
  if (!car || String(car.user_id) !== identity.authUser.id) notFound2();
  return car;
}
async function sellerForDetail(car, accessToken) {
  try {
    const rows = await supabaseJson(
      `/rest/v1/users?select=name,phone&id=eq.${encodeURIComponent(String(car.user_id))}&limit=1`,
      { method: "GET" },
      accessToken
    );
    return rows[0] ?? null;
  } catch {
    return null;
  }
}
function assertImagesOwned(images, identity, existing) {
  const existingImages = new Set(existing ? parseImages(existing.images) : []);
  if (images.some((url) => !isOwnedPublicCarImage(url, identity.authUser.id) && !existingImages.has(url))) {
    badRequest2("\u0643\u0644 \u0635\u0648\u0631\u0629 \u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0645\u0631\u0641\u0648\u0639\u0629 \u0645\u0646 \u062D\u0633\u0627\u0628\u0643 \u0639\u0628\u0631 \u0627\u0644\u0645\u0646\u0635\u0629");
  }
}
function methodFromRef(reference) {
  const match = /^\[(paypal|western)\]\s*(.*)$/i.exec(reference || "");
  return match ? { method: match[1].toLowerCase(), reference: match[2] } : null;
}
function isSame(value, expected) {
  return JSON.stringify(value) === JSON.stringify(expected);
}
function assertSupportedSettings(input) {
  if (!isSame(input.brands, DEFAULT_SETTINGS.brands) || !isSame(input.currencies, DEFAULT_SETTINGS.currencies) || input.terms !== DEFAULT_SETTINGS.terms || input.contactEmail !== "" || input.contactPhone !== "" || input.whatsapp !== "" || input.paypalUrl !== "" || input.featuredDays !== FEATURED_DAYS) {
    badRequest2("\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u0627\u0631\u0643\u0627\u062A \u0648\u0627\u0644\u0639\u0645\u0644\u0627\u062A \u0648\u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0648\u0631\u0627\u0628\u0637 PayPal \u0648\u0645\u062F\u0629 \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645\u0629 \u0641\u064A \u0645\u062E\u0637\u0637 \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u062D\u0627\u0644\u064A");
  }
  if (input.paypalEnabled && !input.paypalEmail) badRequest2("\u0623\u062F\u062E\u0644 \u0628\u0631\u064A\u062F PayPal \u0627\u0644\u062D\u0642\u064A\u0642\u064A\u061B \u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0641\u0638 \u0631\u0627\u0628\u0637 PayPal \u063A\u064A\u0631 \u0627\u0644\u0645\u062F\u0639\u0648\u0645");
  if (input.westernEnabled && !input.westernInstructions.trim()) badRequest2("\u0623\u062F\u062E\u0644 \u062A\u0639\u0644\u064A\u0645\u0627\u062A Western Union \u0642\u0628\u0644 \u062A\u0641\u0639\u064A\u0644\u0647");
}
var supabaseMarketRouter = router({
  settings: publicProcedure.query(async () => loadSettings2()),
  list: publicProcedure.query(async () => {
    const rows = await supabaseJson(`/rest/v1/cars?select=${CAR_FIELDS}&status=in.(approved,pending_featured)&order=created_at.desc`, { method: "GET" });
    return rows.map((car) => mapCar(car)).sort((a, b) => Number(b.featured) - Number(a.featured) || String(b.createdAt).localeCompare(String(a.createdAt)));
  }),
  detail: publicProcedure.input(idSchema2).query(async ({ ctx, input }) => {
    const identity = await (async () => {
      try {
        return await requireSupabaseIdentity(ctx.req);
      } catch {
        return null;
      }
    })();
    const car = await carById(idText(input.id), identity?.accessToken);
    if (!car) notFound2();
    const publicCar = ["approved", "pending_featured"].includes(car.status);
    if (!publicCar && (!identity || String(car.user_id) !== identity.authUser.id && identity.profile.role !== "admin")) notFound2();
    const seller = await sellerForDetail(car, identity?.accessToken);
    return mapCar(car, seller);
  }),
  me: publicProcedure.query(async ({ ctx }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    const rows = await supabaseJson(`/rest/v1/cars?select=${CAR_FIELDS}&user_id=eq.${encodeURIComponent(identity.authUser.id)}&order=created_at.desc`, { method: "GET" }, identity.accessToken);
    const requests = rows.filter((car) => car.status === "pending_featured").map((car) => {
      const parsed = methodFromRef(car.featured_payment_ref);
      return { id: car.id, listingId: car.id, method: parsed?.method || "western", reference: parsed?.reference || "", status: "pending", createdAt: car.created_at, amount: 0, duration: FEATURED_DAYS };
    });
    return { ...identity.user, user: identity.user, listings: rows.map((car) => mapCar(car, identity.profile)), featuredRequests: requests };
  }),
  profile: publicProcedure.input(z5.object({ name: nonEmpty2(100), email: emailSchema3, phone: phoneSchema2 }).strict()).mutation(async ({ ctx, input }) => updateSupabaseProfile(ctx.req, input)),
  create: publicProcedure.input(listingInputSchema2).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    if (!identity.profile.phone?.trim()) badRequest2("\u0623\u0636\u0641 \u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0635\u0627\u0644\u062D\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0642\u0628\u0644 \u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646");
    assertListingValues(input);
    assertImagesOwned(input.images, identity);
    const rows = await supabaseJson(`/rest/v1/cars?select=${CAR_FIELDS}`, {
      method: "POST",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ user_id: identity.authUser.id, brand: input.brand, model: input.model, year: input.year, price: input.price, kilometers: input.mileage, color: input.color, description: input.description, images: input.images, currency: input.currency, status: "pending", is_featured: false })
    }, identity.accessToken);
    const car = rows[0];
    if (!car) throw new TRPCError5({ code: "INTERNAL_SERVER_ERROR", message: "\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u0625\u0639\u0644\u0627\u0646" });
    return { id: car.id };
  }),
  update: publicProcedure.input(idSchema2.extend(listingInputSchema2.shape).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    const id = idText(input.id);
    const current = await requireOwnedCar(identity, id);
    if (current.status === "archived") badRequest2("\u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644 \u0625\u0639\u0644\u0627\u0646 \u0645\u0624\u0631\u0634\u0641");
    if (!identity.profile.phone?.trim()) badRequest2("\u0623\u0636\u0641 \u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0635\u0627\u0644\u062D\u0627\u064B \u0641\u064A \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0642\u0628\u0644 \u0625\u0639\u0627\u062F\u0629 \u062A\u0642\u062F\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646");
    assertListingValues(input);
    assertImagesOwned(input.images, identity, current);
    const rows = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=${CAR_FIELDS}`, {
      method: "PATCH",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ brand: input.brand, model: input.model, year: input.year, price: input.price, kilometers: input.mileage, color: input.color, description: input.description, images: input.images, currency: input.currency, status: "pending", is_featured: false, featured_until: null, featured_payment_ref: null })
    }, identity.accessToken);
    if (!rows[0]) notFound2();
    return { id: rows[0].id, status: "pending" };
  }),
  setSold: publicProcedure.input(idSchema2).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    const id = idText(input.id);
    const current = await requireOwnedCar(identity, id);
    if (visibleStatus(current) !== "approved") badRequest2("\u064A\u0645\u0643\u0646 \u062A\u0639\u0644\u064A\u0645 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629 \u0641\u0642\u0637 \u0639\u0644\u0649 \u0623\u0646\u0647\u0627 \u0645\u0628\u0627\u0639\u0629");
    const rows = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=${CAR_FIELDS}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "sold", is_featured: false, featured_until: null }) }, identity.accessToken);
    if (!rows[0]) notFound2();
    return { id: rows[0].id, status: "sold" };
  }),
  upload: publicProcedure.input(z5.object({ base64: z5.string().max(MAX_IMAGE_BASE64_CHARS2), mime: z5.string().trim().max(32) }).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    const mime = imageMimeSchema2.safeParse(input.mime);
    if (!mime.success) badRequest2("\u0646\u0648\u0639 \u0627\u0644\u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645");
    const { bytes, detected } = decodeUploadedImage(input.base64, mime.data);
    const uploaded = await uploadCarImage(identity.authUser.id, bytes, detected.mime, identity.accessToken);
    return { url: uploaded.url };
  }),
  featureRequest: publicProcedure.input(z5.object({ listingId: idValue, method: z5.enum(["paypal", "western"]), reference: nonEmpty2(256) }).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req);
    const id = idText(input.listingId);
    const car = await requireOwnedCar(identity, id);
    if (car.status !== "approved") badRequest2("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0637\u0644\u0628 \u062A\u0645\u064A\u064A\u0632 \u0625\u0644\u0627 \u0644\u0625\u0639\u0644\u0627\u0646 \u0645\u0646\u0634\u0648\u0631");
    const settings = await loadSettings2(identity.accessToken);
    if (input.method === "paypal" && (!settings.paypalEnabled || !settings.paypalEmail)) badRequest2("\u0627\u0644\u062F\u0641\u0639 \u0639\u0628\u0631 PayPal \u063A\u064A\u0631 \u0645\u0641\u0639\u0644");
    if (input.method === "western" && (!settings.westernEnabled || !settings.westernInstructions)) badRequest2("Western Union \u063A\u064A\u0631 \u0645\u0641\u0639\u0644");
    const rows = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=${CAR_FIELDS}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "pending_featured", featured_payment_ref: `[${input.method}] ${input.reference}` }) }, identity.accessToken);
    if (!rows[0]) notFound2();
    return { id: rows[0].id, status: "pending" };
  }),
  contact: publicProcedure.input(z5.object({ name: nonEmpty2(100), email: emailSchema3, message: nonEmpty2(4).max(5e3) }).strict()).mutation(() => {
    throw new TRPCError5({ code: "PRECONDITION_FAILED", message: "\u0644\u0627 \u064A\u0648\u062C\u062F \u062C\u062F\u0648\u0644 \u0631\u0633\u0627\u0626\u0644 \u062A\u0648\u0627\u0635\u0644 \u0641\u064A \u0645\u062E\u0637\u0637 \u0627\u0644\u0645\u0648\u0642\u0639\u061B \u0627\u0633\u062A\u062E\u062F\u0645 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639 \u0628\u062F\u0644\u0627\u064B \u0645\u0646 \u062D\u0641\u0638 \u0631\u0633\u0627\u0644\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645\u0629" });
  }),
  adminOverview: publicProcedure.query(async ({ ctx }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    const [cars, users2, settings] = await Promise.all([
      supabaseJson(`/rest/v1/cars?select=${CAR_FIELDS}&order=created_at.desc`, { method: "GET" }, identity.accessToken),
      supabaseJson(`/rest/v1/users?select=${USER_FIELDS}&order=created_at.desc`, { method: "GET" }, identity.accessToken),
      loadSettings2(identity.accessToken)
    ]);
    const people = new Map(users2.map((person) => [String(person.id), person]));
    const requests = cars.filter((car) => car.status === "pending_featured").map((car) => {
      const ref = methodFromRef(car.featured_payment_ref);
      const seller = people.get(String(car.user_id));
      return { id: car.id, listingId: car.id, method: ref?.method || "western", reference: ref?.reference || "", status: "pending", createdAt: car.created_at, listingTitle: `${car.brand} ${car.model} ${car.year}`, userName: seller?.name || "", amount: String(settings.featuredPrice), duration: FEATURED_DAYS };
    });
    return {
      listings: cars.map((car) => mapCar(car, people.get(String(car.user_id)) || null)),
      users: users2.map((person) => ({ ...toAdminUser(person) })),
      requests,
      messages: [],
      stats: { total: cars.length, pending: cars.filter((car) => car.status === "pending").length, featured: cars.filter(isActiveFeatured).length, users: users2.length }
    };
  }),
  moderate: publicProcedure.input(z5.object({ id: idValue, status: z5.enum(["approved", "rejected", "sold"]), reason: optionalText2(2e3).optional() }).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    const id = idText(input.id);
    if (input.reason?.trim()) badRequest2("\u062D\u0641\u0638 \u0633\u0628\u0628 \u0627\u0644\u0631\u0641\u0636 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0641\u064A \u0645\u062E\u0637\u0637 \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u062D\u0627\u0644\u064A");
    if (!await carById(id, identity.accessToken)) notFound2();
    const patch = { status: input.status };
    if (input.status !== "approved") Object.assign(patch, { is_featured: false, featured_until: null });
    const rows = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=${CAR_FIELDS}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) }, identity.accessToken);
    if (!rows[0]) notFound2();
    return { id: rows[0].id, status: input.status };
  }),
  deleteListing: publicProcedure.input(idSchema2).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    const id = idText(input.id);
    if (!await carById(id, identity.accessToken)) notFound2("\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    const deleted = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=id`, { method: "DELETE", headers: { Prefer: "return=representation" } }, identity.accessToken);
    if (!deleted[0]) throw new TRPCError5({ code: "FORBIDDEN", message: "\u0644\u0645 \u064A\u064F\u062D\u0630\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0627\u0644\u0625\u062F\u0627\u0631\u0629 \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639" });
    return { id: input.id, deleted: true };
  }),
  featureDecision: publicProcedure.input(z5.object({ id: idValue, approved: z5.boolean(), paymentConfirmed: z5.boolean() }).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    const id = idText(input.id);
    const car = await carById(id, identity.accessToken);
    if (!car || car.status !== "pending_featured") badRequest2("\u0637\u0644\u0628 \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0623\u0648 \u062A\u0645\u062A \u0645\u0631\u0627\u062C\u0639\u062A\u0647");
    if (input.approved && !input.paymentConfirmed) badRequest2("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0639\u062A\u0645\u0627\u062F \u0627\u0644\u062A\u0645\u064A\u064A\u0632 \u0642\u0628\u0644 \u062A\u0623\u0643\u064A\u062F \u0627\u0644\u062F\u0641\u0639 \u064A\u062F\u0648\u064A\u0627\u064B");
    const patch = input.approved ? { status: "approved", is_featured: true, featured_until: new Date(Date.now() + FEATURED_DAYS * 864e5).toISOString() } : { status: "approved", is_featured: false, featured_until: null };
    const rows = await supabaseJson(`/rest/v1/cars?id=eq.${encodeURIComponent(id)}&select=${CAR_FIELDS}`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(patch) }, identity.accessToken);
    if (!rows[0]) notFound2();
    return { id: rows[0].id, status: input.approved ? "approved" : "rejected", ...input.approved ? { featuredUntil: rows[0].featured_until } : {} };
  }),
  userStatus: publicProcedure.input(z5.object({ id: idValue, blocked: z5.boolean() }).strict()).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    const id = idText(input.id);
    if (id === identity.authUser.id) badRequest2("\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u062D\u0633\u0627\u0628\u0643");
    const rows = await supabaseJson(`/rest/v1/users?id=eq.${encodeURIComponent(id)}&select=${USER_FIELDS}&limit=1`, { method: "GET" }, identity.accessToken);
    const target = rows[0];
    if (!target) notFound2("\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    if (target.role === "admin") badRequest2("\u0644\u0627 \u064A\u0645\u0643\u0646 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628 \u0625\u062F\u0627\u0631\u064A");
    const changed = await supabaseJson(`/rest/v1/users?id=eq.${encodeURIComponent(id)}&select=id`, { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: input.blocked ? "blocked" : "active" }) }, identity.accessToken);
    if (!changed[0]) throw new TRPCError5({ code: "FORBIDDEN", message: "\u0644\u0645 \u062A\u062A\u063A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0627\u0644\u0625\u062F\u0627\u0631\u0629 \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639" });
    return { id: input.id, blocked: input.blocked };
  }),
  deleteUser: publicProcedure.input(idSchema2).mutation(async ({ ctx, input }) => {
    await requireSupabaseIdentity(ctx.req, true);
    throw new TRPCError5({ code: "PRECONDITION_FAILED", message: `\u062D\u0630\u0641 \u0645\u0633\u062A\u062E\u062F\u0645 Auth \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0628\u062F\u0648\u0646 \u0648\u0627\u062C\u0647\u0629 \u0625\u062F\u0627\u0631\u064A\u0629 \u0622\u0645\u0646\u0629. \u0627\u0633\u062A\u062E\u062F\u0645 ${SITE_ADMIN_URL}\u061B \u0644\u0645 \u064A\u064F\u062D\u0630\u0641 \u0623\u064A \u0645\u0633\u062A\u062E\u062F\u0645 \u0623\u0648 \u0625\u0639\u0644\u0627\u0646.` });
  }),
  saveSettings: publicProcedure.input(settingsSchema2).mutation(async ({ ctx, input }) => {
    const identity = await requireSupabaseIdentity(ctx.req, true);
    assertSupportedSettings(input);
    const existing = await fetchSettings(identity.accessToken);
    if (!existing) throw new TRPCError5({ code: "PRECONDITION_FAILED", message: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0635\u0641 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0639\u0627\u0645 \u0642\u0627\u0628\u0644 \u0644\u0644\u062A\u062D\u062F\u064A\u062B \u0641\u064A \u0627\u0644\u0645\u0648\u0642\u0639" });
    const rows = await supabaseJson(`/rest/v1/site_settings?id=eq.${encodeURIComponent(String(existing.id))}&select=id,featured_price,western_union_info,paypal_email,paypal_enabled,western_union_enabled`, {
      method: "PATCH",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ featured_price: input.featuredPrice, western_union_info: input.westernInstructions || null, paypal_email: input.paypalEmail || null, paypal_enabled: input.paypalEnabled, western_union_enabled: input.westernEnabled })
    }, identity.accessToken);
    if (!rows[0]) throw new TRPCError5({ code: "INTERNAL_SERVER_ERROR", message: "\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A" });
    return loadSettings2(identity.accessToken);
  })
});
function toAdminUser(profile) {
  return { id: profile.id, name: profile.name, email: profile.email, phone: profile.phone, role: profile.role || "user", blocked: ["blocked", "suspended", "disabled", "banned"].includes((profile.status || "").toLowerCase()), status: profile.status, createdAt: profile.created_at };
}

// server/routers.ts
var appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (!isSupabaseConfigured()) return ctx.user;
      return (await getSupabaseIdentity(ctx.req))?.user ?? null;
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      if (isSupabaseConfigured()) {
        await revokeSupabaseSession(ctx.req);
        clearSupabaseSessionCookies(ctx.req, ctx.res);
      } else {
        const cookieOptions2 = getSessionCookieOptions(ctx.req);
        ctx.res.clearCookie(getSessionCookieName(ctx.req), { ...cookieOptions2, maxAge: -1 });
      }
      return { success: true };
    })
  }),
  market: supabaseMarketRouter
});

// server/_core/context.ts
async function createContext(opts) {
  let user = null;
  try {
    if (!isSupabaseConfigured()) user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/cors.ts
import { BlockList, isIP } from "node:net";
var LOOPBACK_IPS = new BlockList();
LOOPBACK_IPS.addSubnet("127.0.0.0", 8, "ipv4");
LOOPBACK_IPS.addAddress("::1", "ipv6");
LOOPBACK_IPS.addSubnet("::ffff:127.0.0.0", 104, "ipv6");
function configuredOrigin2(name) {
  const value = process.env[name];
  if (!value) return null;
  try {
    const url = new URL(value);
    return (url.protocol === "https:" || url.protocol === "http:") && url.origin === value ? value : null;
  } catch {
    return null;
  }
}
function pairedPreviewOrigin(packagerOrigin) {
  const url = new URL(packagerOrigin);
  const previewHostname = url.hostname.replace(/^8081-/, "8328-");
  if (previewHostname === url.hostname) return null;
  url.hostname = previewHostname;
  return url.origin;
}
function trustedExpoWebOrigins() {
  const origins = /* @__PURE__ */ new Set();
  const packager = configuredOrigin2("EXPO_PACKAGER_PROXY_URL");
  const preview = configuredOrigin2("EXPO_WEB_PREVIEW_URL");
  for (const configured of [packager, preview]) {
    if (configured && !originHasLoopbackHostname(configured)) origins.add(configured);
  }
  if (packager && !originHasLoopbackHostname(packager)) {
    const paired = pairedPreviewOrigin(packager);
    if (paired) origins.add(paired);
  }
  return origins;
}
function isLoopbackApiHost(hostname) {
  const normalized = hostname.trim().toLowerCase().replace(/^\[|\]$/g, "").replace(/\.+$/, "");
  if (normalized === "localhost" || normalized.endsWith(".localhost")) {
    return true;
  }
  const family = isIP(normalized);
  if (family === 0) return false;
  return LOOPBACK_IPS.check(normalized, family === 4 ? "ipv4" : "ipv6");
}
function originHasLoopbackHostname(origin) {
  try {
    return isLoopbackApiHost(new URL(origin).hostname);
  } catch {
    return false;
  }
}
function requestOrigin(req) {
  const proto = req.headers["x-forwarded-proto"]?.toString().split(",")[0]?.trim() || req.protocol;
  const host = req.headers["x-forwarded-host"]?.toString().split(",")[0]?.trim() || req.get("host");
  if (!host || proto !== "http" && proto !== "https") return null;
  return `${proto}://${host}`;
}
function configuredLocalExpoWebOrigins() {
  const origins = /* @__PURE__ */ new Set();
  for (const name of ["EXPO_PACKAGER_PROXY_URL", "EXPO_WEB_PREVIEW_URL"]) {
    const origin = configuredOrigin2(name);
    if (!origin) continue;
    const url = new URL(origin);
    if (url.protocol === "http:" && isLoopbackApiHost(url.hostname)) origins.add(origin);
  }
  return origins;
}
function createCorsMiddleware(allowedOrigins = trustedExpoWebOrigins(), localApiRequest = (hostname) => isLoopbackApiHost(hostname)) {
  return (req, res, next) => {
    const origin = req.headers.origin;
    res.vary("Origin");
    if (!origin) {
      next();
      return;
    }
    const loopbackOrigin = originHasLoopbackHostname(origin);
    const allowedLocalOrigin = localApiRequest(req.hostname) && configuredLocalExpoWebOrigins().has(origin);
    const allowedConfiguredOrigin = !loopbackOrigin && allowedOrigins.has(origin);
    const allowedSameOrigin = !loopbackOrigin && requestOrigin(req) === origin;
    if (!allowedConfiguredOrigin && !allowedLocalOrigin && !allowedSameOrigin) {
      res.status(403).json({ error: "origin_not_allowed" });
      return;
    }
    res.header("Access-Control-Allow-Origin", origin);
    res.header(
      "Access-Control-Allow-Methods",
      "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    );
    res.header(
      "Access-Control-Allow-Headers",
      "Content-Type, Accept, Authorization, X-Requested-With, X-Sayarty-Origin"
    );
    res.header("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") {
      res.sendStatus(204);
      return;
    }
    next();
  };
}

// server/local-auth.ts
import { createHash as createHash3, randomBytes as randomBytes3, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and as and3, desc as desc2, eq as eq4, isNull as isNull2 } from "drizzle-orm";
var scrypt = promisify(scryptCallback);
var LOCAL_ADMIN_EMAIL = "admin@sayarty.store";
var LOCAL_ADMIN_PASSWORD = process.env.LOCAL_ADMIN_PASSWORD || "admin123";
var LOCAL_ADMIN_OPEN_ID = "local_admin_sayarty";
var OTP_TTL_MS = 10 * 60 * 1e3;
var MAX_OTP_ATTEMPTS = 5;
async function hashPassword(password) {
  const salt = randomBytes3(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt}$${derived.toString("hex")}`;
}
async function verifyPassword(password, encoded) {
  const [algorithm, salt, stored] = encoded.split("$");
  if (algorithm !== "scrypt" || !salt || !stored || stored.length !== 128) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(stored, "hex");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}
function normalizeEmail(email) {
  return email.trim().toLowerCase();
}
function codeHash(code) {
  return createHash3("sha256").update(code).digest("hex");
}
function makeCode() {
  return String(Math.floor(1e5 + Math.random() * 9e5));
}
async function sendOtp(email, code, purpose) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL || "onboarding@resend.dev";
  if (!apiKey) throw new Error("\u062E\u062F\u0645\u0629 \u0627\u0644\u0628\u0631\u064A\u062F \u063A\u064A\u0631 \u0645\u0647\u064A\u0623\u0629");
  const action = purpose === "register" ? "\u062A\u0641\u0639\u064A\u0644 \u062D\u0633\u0627\u0628\u0643" : "\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631";
  const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ from, to: [email], subject: `\u0633\u064A\u0651\u0627\u0631\u0629 \u2014 \u0631\u0645\u0632 ${action}`, html: `<div dir="rtl" style="font-family:Arial,sans-serif"><h2>\u0633\u064A\u0651\u0627\u0631\u0629</h2><p>\u0631\u0645\u0632 ${action} \u0647\u0648:</p><p style="font-size:32px;font-weight:bold;letter-spacing:8px">${code}</p><p>\u064A\u0646\u062A\u0647\u064A \u0627\u0644\u0631\u0645\u0632 \u062E\u0644\u0627\u0644 10 \u062F\u0642\u0627\u0626\u0642. \u0644\u0627 \u062A\u0634\u0627\u0631\u0643\u0647 \u0645\u0639 \u0623\u064A \u0634\u062E\u0635.</p></div>` }) });
  if (!response.ok) {
    const detail = await response.text();
    console.error("[Resend] OTP failed", response.status, detail);
    throw new Error("\u062A\u0639\u0630\u0651\u0631 \u0625\u0631\u0633\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642");
  }
}
async function ensureLocalAdmin() {
  const db = await getDb();
  if (!db) return;
  const existing = (await db.select().from(users).where(eq4(users.openId, LOCAL_ADMIN_OPEN_ID)).limit(1))[0];
  let userId = existing?.id;
  if (!userId) {
    const inserted = await db.insert(users).values({ openId: LOCAL_ADMIN_OPEN_ID, name: "\u0645\u062F\u064A\u0631 \u0633\u064A\u0651\u0627\u0631\u0629", email: LOCAL_ADMIN_EMAIL, loginMethod: "local", role: "admin", blocked: false }).$returningId();
    userId = inserted[0]?.id;
  }
  if (!userId) throw new Error("Unable to initialize local admin");
  const credential = (await db.select().from(localCredentials).where(eq4(localCredentials.userId, userId)).limit(1))[0];
  if (!credential) await db.insert(localCredentials).values({ userId, passwordHash: await hashPassword(LOCAL_ADMIN_PASSWORD) });
  else if (existing?.role !== "admin" || existing.blocked) await db.update(users).set({ role: "admin", blocked: false }).where(eq4(users.id, userId));
}
async function loginLocal(email, password) {
  const db = await getDb();
  if (!db) return null;
  const user = (await db.select().from(users).where(eq4(users.email, normalizeEmail(email))).limit(1))[0];
  if (!user || user.blocked) return null;
  const credential = (await db.select().from(localCredentials).where(eq4(localCredentials.userId, user.id)).limit(1))[0];
  if (!credential || !await verifyPassword(password, credential.passwordHash)) return null;
  await db.update(users).set({ lastSignedIn: /* @__PURE__ */ new Date() }).where(eq4(users.id, user.id));
  return { token: await sdk.createSessionToken(user.openId, { name: user.name || "" }), user: { ...user, lastSignedIn: /* @__PURE__ */ new Date() } };
}
async function saveOtp(email, purpose, extra = {}) {
  const db = await getDb();
  if (!db) throw new Error("\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629");
  const code = makeCode();
  await db.delete(otpCodes).where(and3(eq4(otpCodes.email, email), eq4(otpCodes.purpose, purpose)));
  await db.insert(otpCodes).values({ email, purpose, codeHash: codeHash(code), name: extra.name ?? null, passwordHash: extra.passwordHash ?? null, expiresAt: new Date(Date.now() + OTP_TTL_MS) });
  await sendOtp(email, code, purpose);
}
async function requestRegistrationOtp(emailInput, name, password) {
  const email = normalizeEmail(emailInput);
  const db = await getDb();
  if (!db) throw new Error("\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629");
  const existing = (await db.select({ id: users.id }).from(users).where(eq4(users.email, email)).limit(1))[0];
  if (existing) throw new Error("\u064A\u0648\u062C\u062F \u062D\u0633\u0627\u0628 \u0628\u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A");
  await saveOtp(email, "register", { name: name.trim(), passwordHash: await hashPassword(password) });
}
async function verifyRegistrationOtp(emailInput, code) {
  const email = normalizeEmail(emailInput);
  const db = await getDb();
  if (!db) throw new Error("\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629");
  const otp = (await db.select().from(otpCodes).where(and3(eq4(otpCodes.email, email), eq4(otpCodes.purpose, "register"), isNull2(otpCodes.consumedAt))).orderBy(desc2(otpCodes.createdAt)).limit(1))[0];
  if (!otp || otp.expiresAt.getTime() < Date.now() || otp.attempts >= MAX_OTP_ATTEMPTS) throw new Error("\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D \u0623\u0648 \u0645\u0646\u062A\u0647\u064A");
  if (otp.codeHash !== codeHash(code.trim())) {
    await db.update(otpCodes).set({ attempts: otp.attempts + 1 }).where(eq4(otpCodes.id, otp.id));
    throw new Error("\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D \u0623\u0648 \u0645\u0646\u062A\u0647\u064A");
  }
  const openId = `local_email_${createHash3("sha256").update(email).digest("hex").slice(0, 48)}`;
  const userId = await db.transaction(async (tx) => {
    await tx.update(otpCodes).set({ consumedAt: /* @__PURE__ */ new Date() }).where(eq4(otpCodes.id, otp.id));
    const inserted = await tx.insert(users).values({ openId, name: otp.name || "\u0645\u0633\u062A\u062E\u062F\u0645 \u0633\u064A\u0651\u0627\u0631\u0629", email, loginMethod: "email", role: "user", blocked: false }).$returningId();
    const id = inserted[0]?.id;
    if (!id || !otp.passwordHash) throw new Error("\u062A\u0639\u0630\u0651\u0631 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u062D\u0633\u0627\u0628");
    await tx.insert(localCredentials).values({ userId: id, passwordHash: otp.passwordHash });
    return id;
  });
  const user = (await db.select().from(users).where(eq4(users.id, userId)).limit(1))[0];
  return { token: await sdk.createSessionToken(user.openId, { name: user.name || "" }), user };
}
async function requestResetOtp(emailInput) {
  const email = normalizeEmail(emailInput);
  const db = await getDb();
  if (!db) throw new Error("\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629");
  const user = (await db.select({ id: users.id }).from(users).where(eq4(users.email, email)).limit(1))[0];
  if (!user) throw new Error("\u0644\u0627 \u064A\u0648\u062C\u062F \u062D\u0633\u0627\u0628 \u0628\u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A");
  await saveOtp(email, "reset");
}
async function resetPassword(emailInput, code, password) {
  const email = normalizeEmail(emailInput);
  const db = await getDb();
  if (!db) throw new Error("\u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629");
  const otp = (await db.select().from(otpCodes).where(and3(eq4(otpCodes.email, email), eq4(otpCodes.purpose, "reset"), isNull2(otpCodes.consumedAt))).orderBy(desc2(otpCodes.createdAt)).limit(1))[0];
  if (!otp || otp.expiresAt.getTime() < Date.now() || otp.attempts >= MAX_OTP_ATTEMPTS) throw new Error("\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D \u0623\u0648 \u0645\u0646\u062A\u0647\u064A");
  if (otp.codeHash !== codeHash(code.trim())) {
    await db.update(otpCodes).set({ attempts: otp.attempts + 1 }).where(eq4(otpCodes.id, otp.id));
    throw new Error("\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D \u0623\u0648 \u0645\u0646\u062A\u0647\u064A");
  }
  const user = (await db.select({ id: users.id }).from(users).where(eq4(users.email, email)).limit(1))[0];
  if (!user) throw new Error("\u0627\u0644\u062D\u0633\u0627\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
  await db.transaction(async (tx) => {
    await tx.update(otpCodes).set({ consumedAt: /* @__PURE__ */ new Date() }).where(eq4(otpCodes.id, otp.id));
    await tx.update(localCredentials).set({ passwordHash: await hashPassword(password) }).where(eq4(localCredentials.userId, user.id));
  });
}

// server/_core/index.ts
function registerLegacyAuthRoutes(app) {
  registerOAuthRoutes(app);
  app.get("/api/auth/provider", (_req, res) => {
    res.json({ provider: "local" });
  });
  app.post("/api/auth/local-login", async (req, res) => {
    const parsed = z6.object({ email: z6.string().email().max(320), password: z6.string().min(1).max(256) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629" });
      return;
    }
    const result = await loginLocal(parsed.data.email.trim().toLowerCase(), parsed.data.password);
    if (!result) {
      res.status(401).json({ error: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629" });
      return;
    }
    res.cookie(getSessionCookieName(req), result.token, { ...getSessionCookieOptions(req), maxAge: 1e3 * 60 * 60 * 24 * 365 });
    res.json({ user: { id: result.user.id, openId: result.user.openId, name: result.user.name, email: result.user.email, phone: result.user.phone, role: result.user.role, blocked: result.user.blocked } });
  });
  app.post("/api/auth/register/request", async (req, res) => {
    const parsed = z6.object({ email: z6.string().email().max(320), name: z6.string().trim().min(2).max(100), password: z6.string().min(8).max(256) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0644\u0628\u0631\u064A\u062F \u0648\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u0646 8 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644" });
      return;
    }
    try {
      await requestRegistrationOtp(parsed.data.email, parsed.data.name, parsed.data.password);
      res.json({ ok: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "\u062A\u0639\u0630\u0651\u0631 \u0625\u0631\u0633\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642" });
    }
  });
  app.post("/api/auth/register/verify", async (req, res) => {
    const parsed = z6.object({ email: z6.string().email().max(320), code: z6.string().regex(/^\d{6}$/) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642 \u0627\u0644\u0645\u0643\u0648\u0651\u0646 \u0645\u0646 6 \u0623\u0631\u0642\u0627\u0645" });
      return;
    }
    try {
      const result = await verifyRegistrationOtp(parsed.data.email, parsed.data.code);
      res.cookie(getSessionCookieName(req), result.token, { ...getSessionCookieOptions(req), maxAge: 1e3 * 60 * 60 * 24 * 365 });
      res.json({ user: { id: result.user.id, openId: result.user.openId, name: result.user.name, email: result.user.email, phone: result.user.phone, role: result.user.role, blocked: result.user.blocked } });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "\u062A\u0639\u0630\u0651\u0631 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628" });
    }
  });
  app.post("/api/auth/password/request", async (req, res) => {
    const parsed = z6.object({ email: z6.string().email().max(320) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u0623\u062F\u062E\u0644 \u0628\u0631\u064A\u062F\u0627\u064B \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A\u0627\u064B \u0635\u0627\u0644\u062D\u0627\u064B" });
      return;
    }
    try {
      await requestResetOtp(parsed.data.email);
      res.json({ ok: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "\u062A\u0639\u0630\u0651\u0631 \u0625\u0631\u0633\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u0627\u0633\u062A\u0639\u0627\u062F\u0629" });
    }
  });
  app.post("/api/auth/password/reset", async (req, res) => {
    const parsed = z6.object({ email: z6.string().email().max(320), code: z6.string().regex(/^\d{6}$/), password: z6.string().min(8).max(256) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0631\u0645\u0632 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629" });
      return;
    }
    try {
      await resetPassword(parsed.data.email, parsed.data.code, parsed.data.password);
      res.json({ ok: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "\u062A\u0639\u0630\u0651\u0631 \u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" });
    }
  });
}
async function startServer() {
  const app = express();
  const server = createServer(app);
  const supabaseEnabled = isSupabaseConfigured();
  app.use(createCorsMiddleware());
  if (!supabaseEnabled) app.use(clearLegacySessionCookie());
  app.use(express.json({ limit: "7mb" }));
  app.use(express.urlencoded({ limit: "7mb", extended: true }));
  registerStorageProxy(app);
  if (supabaseEnabled) {
    registerSupabaseAuthRoutes(app);
  } else {
    registerLegacyAuthRoutes(app);
  }
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  const webDist = path.resolve(process.cwd(), "web-dist");
  if (existsSync(webDist)) {
    app.use(express.static(webDist, { index: false, maxAge: "1h" }));
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api/") || req.path.startsWith("/manus-storage/")) return next();
      res.sendFile(path.join(webDist, "index.html"));
    });
  }
  const port = parseInt(process.env.PORT || "3000");
  if (!supabaseEnabled) await ensureLocalAdmin();
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}
startServer().catch(() => {
  console.error("[api] server failed to start");
});
